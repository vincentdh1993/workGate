﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using ScanToStyleCS;
using ScanToStyleCS.FabricExtractor.Models;
using ScanToStyleCS.FabricExtractor.OcrEngine;
using ScanToStyleCS.FabricExtractor.OcrEngine.Models;
using ScanToStyleCS.FabricExtractor.Utils;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using static ScanToStyleCS.CareLabelAnalyzer;

namespace ScanToStyleTest
{
    [TestClass]
    public class CareLabelTest
    {
        [TestMethod]
        public void TestGetRotateAngle()
        {
            string path = "DemoImages/source00156.jpg";
            int angle = ImageUtils.GetRotateAngle(path);
            Console.WriteLine(angle);

            Assert.IsTrue(Math.Abs(angle - 6) < 2);
        }

        [TestMethod]
        public void TestFabricFinder()
        {
            OcrResultItem ocrResult = loadJson(@"D:\LABEL_TEMP\통합\TestSet05_with_Label_0425_mod\source00041.json");
            FabricFinder fabricFinder = new FabricFinder(ocrResult.Images[0].Fields);

            List<FabricItem> fabricItems = fabricFinder.MakeFabricInfo();
            foreach (FabricItem fabricItem in fabricItems)
            {
                Console.WriteLine($"{fabricItem.Label} {fabricItem.Percent} | {fabricItem.OriginLabel}");
            }

            Console.WriteLine(fabricFinder);

            Assert.IsTrue(true);
        }

        [TestMethod]
        public void TestGetIntersection()
        {
            BoundingPoly a = new BoundingPoly();
            BoundingPoly b = new BoundingPoly();

            //(1, 2), (3, 1), (4, 2), (3, 4), (1, 3)
            a.Vertices = new List<ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point> {
                new ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point(1,2),
            new ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point(3,1),
            new ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point(4,2),
            new ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point(3,4),
            new ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point(1,3)};
            //(2, 3), (3, 2), (5, 3), (5, 4)
            b.Vertices = new List<ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point> {
                new ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point(2,3),
            new ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point(3,2),
            new ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point(5,3),
            new ScanToStyleCS.FabricExtractor.OcrEngine.Models.Point(5,4)};

            double intersectArea = a.GetIntersection(b);
            Console.WriteLine(intersectArea);
            Console.WriteLine(a.GetIoU(b));
        }

        [TestMethod]
        public void TestGetSimilarFabric()
        {
            Tuple<string, double> test1 = FabricStringUtils.GetSimilarFabric("폴리이스터");
            StringAssert.Equals(test1.Item1, "폴리에스터");

            Tuple<string, double> test2 = FabricStringUtils.GetSimilarFabric("polyestee");
            StringAssert.Equals(test2.Item1, "폴리에스터");

            Tuple<string, double> test3 = FabricStringUtils.GetSimilarFabric("BAVLNADE");

            Assert.IsTrue(test3.Item1 == null);
        }

        [TestMethod]
        public void TestGetSimilarScore()
        {
            double simScore = FabricStringUtils.GetSimilarScore("폴리에스터", "폴리에스테르");
            Console.WriteLine(simScore);
        }


        [TestMethod]
        public void TestSplitKorean()
        {
            string result = ScanToStyleCS.FabricExtractor.Utils.FabricStringUtils.SplitKoreanPhonetics("가난다ab");
            Console.WriteLine(result);
            StringAssert.Equals(result, "ㄱㅏ   ㄴㅏㄴㄷㅏ   ab");
        }

        public OcrResultItem loadJson(string path = "resultJson/0460_1.json")
        {
            string jsonText = System.IO.File.ReadAllText(path);
            return JsonConvert.DeserializeObject<OcrResultItem>(jsonText);
        }
        public Bitmap LoadBitmap(string path)
        {
            if (File.Exists(path))
            {
                // open file in read only mode
                using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read))
                // get a binary reader for the file stream
                using (BinaryReader reader = new BinaryReader(stream))
                {
                    // copy the content of the file into a memory stream
                    var memoryStream = new MemoryStream(reader.ReadBytes((int)stream.Length));
                    // make a new Bitmap object the owner of the MemoryStream
                    return new Bitmap(memoryStream);
                }
            }
            else
            {
                return null;
            }
        }
    }
}
