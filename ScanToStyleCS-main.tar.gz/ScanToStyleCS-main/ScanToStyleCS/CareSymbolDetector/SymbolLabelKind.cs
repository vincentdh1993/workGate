﻿namespace ScanToStyleCS
{
    /// <summary>
    /// YOLO 레이블 종류
    /// </summary>
    public enum SymbolLabelKind
    {
        /// <summary>
        /// 일반
        /// </summary>
        Generic
    }
}