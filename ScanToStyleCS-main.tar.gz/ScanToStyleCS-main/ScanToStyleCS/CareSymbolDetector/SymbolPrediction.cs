﻿using System.Drawing;

namespace ScanToStyleCS
{
    /// <summary>
    /// CareSymbol 예측
    /// </summary>
    public class SymbolPrediction
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////// Property
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 레이블 - Label

        /// <summary>
        /// 레이블
        /// </summary>
        public SymbolLabel Label { get; set; }

        #endregion
        #region 사각형 - Rectangle

        /// <summary>
        /// 사각형
        /// </summary>
        public RectangleF Rectangle { get; set; }

        #endregion
        #region 점수 - Score

        /// <summary>
        /// 점수
        /// </summary>
        public float Score { get; set; }

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Constructor
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 생성자 - SymbolPrediction()

        /// <summary>
        /// 생성자
        /// </summary>
        public SymbolPrediction()
        {
        }

        #endregion
        #region 생성자 - SymbolPrediction(label)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="label">레이블</param>
        public SymbolPrediction(SymbolLabel label)
        {
            Label = label;
        }

        #endregion
        #region 생성자 - SymbolPrediction(label, confidence)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="label">레이블</param>
        /// <param name="confidence">신뢰도</param>
        public SymbolPrediction(SymbolLabel label, float confidence) : this(label)
        {
            Score = confidence;
        }

        #endregion
    }
}