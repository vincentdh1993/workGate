﻿using Microsoft.ML.OnnxRuntime;
using System.Collections.Generic;
using System.Drawing;

namespace ScanToStyleCS
{
    /// <summary>
    /// YOLO 모델
    /// </summary>
    public abstract class SymbolModel
    {
        #region 너비 - Width

        /// <summary>
        /// 너비
        /// </summary>
        public abstract int Width { get; set; }

        #endregion
        #region 높이 - Height

        /// <summary>
        /// 높이
        /// </summary>
        public abstract int Height { get; set; }

        #endregion

        #region 인풋 형식 enum class
        /// <summary>
        /// RgbLong : 정수 타입 (-1, 3, x, y)
        /// RgbFloat : 실수 타입 (-1, 3, x, y)
        /// </summary>
        public enum ColorField
        {
            RgbLong,
            RgbFloat,
        }
        public abstract ColorField InputColor { get; set; }
        #endregion

        #region Label 갯수 - LabelCount

        /// <summary>
        /// 차원
        /// </summary>
        public abstract int LabelCount { get; set; }

        #endregion

        #region 신뢰도 - Confidence

        /// <summary>
        /// 신뢰도
        /// </summary>
        public abstract float Confidence { get; set; }

        #endregion

        #region 오버랩 - Overlap

        /// <summary>
        /// 오버랩
        /// </summary>
        public abstract float Overlap { get; set; }

        #endregion
        #region 출력 배열 - OutputArray

        /// <summary>
        /// 출력 배열
        /// </summary>
        public abstract string[] OutputArray { get; set; }

        #endregion
        #region 레이블 리스트 - LabelList

        /// <summary>
        /// 레이블 리스트
        /// </summary>
        public abstract List<SymbolLabel> LabelList { get; set; }
        #endregion

        #region 탐지 파싱하기 - ParseDetect(inferenceResult, image)

        /// <summary>
        /// 탐지 파싱하기
        /// </summary>
        public abstract List<SymbolPrediction> ParseDetect(IDisposableReadOnlyCollection<DisposableNamedOnnxValue> inferenceResult, Image image);
        #endregion

        #region 범위 내 자르기 - Clamp(value, minimumValue, maximumValue)

        /// <summary>
        /// 범위 내 자르기
        /// </summary>
        /// <param name="value">값</param>
        /// <param name="minimumValue">최소값</param>
        /// <param name="maximumValue">최대값</param>
        /// <returns>값</returns>
        public float Clamp(float value, float minimumValue, float maximumValue)
        {
            return (value < minimumValue) ? minimumValue : (value > maximumValue) ? maximumValue : value;
        }

        #endregion
    }
}