﻿using ScanToStyleCS.FabricExtractor.Models;
using ScanToStyleCS.FabricExtractor.OcrEngine.Models;
using ScanToStyleCS.FabricExtractor.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ScanToStyleCS.FabricExtractor.OcrEngine
{
    public class FabricFinder
    {
        private List<Field> fields;

        public List<Field> SortFields()
        {
            double prevDy = .0f;

            List<List<Field>> resultFields = new List<List<Field>>();
            for (int i = 0; i < fields.Count; i++)
            {
                if (fields[i].Slope == -10000 && i > 0)
                {
                    for (int y = i - 1; y > 0; y--)
                    {
                        if (fields[i].CalcIntersectWidth(fields[y]) > 0)
                        {
                            fields[i].SetLineSlope(fields[y].Slope);
                            break;
                        }
                    }
                }

                if (fields[i].Slope == -10000)
                {
                    fields[i].SetLineSlope(0);
                }

                List<Field> sameLineFields = new List<Field>();
                int sameLineIdx = -1;
                for (int x = 0; x < resultFields.Count; x++)
                {
                    bool isSameLine = IsSameLineFields(fields[i], resultFields[x], prevDy);
                    if (isSameLine)
                    {
                        sameLineIdx = x;
                    }
                }

                if (sameLineIdx != -1)
                {
                    resultFields[sameLineIdx].Add(fields[i]);
                }
                else
                {
                    resultFields.Add(new List<Field> { fields[i] });
                }
                prevDy = fields[i].Slope;
            }

            if (resultFields.Count > 0)
            {
                List<List<Field>> resultFields2 = new List<List<Field>> { resultFields[0] };
                for (int i = 1; i < resultFields.Count; i++)
                {
                    if (IsSameLineFields(resultFields[i], resultFields2[resultFields2.Count - 1]))
                    {
                        resultFields2[resultFields2.Count - 1].AddRange(resultFields[i]);
                    }
                    else
                    {
                        resultFields2.Add(resultFields[i]);
                    }
                }
                resultFields = resultFields2;
            }
            List<Field> retFields = new List<Field>();
            for (int i = 0; i < resultFields.Count; i++)
            {
                resultFields[i].Sort((field1, field2) => field1.GetMinX().CompareTo(field2.GetMinX()));
                foreach (Field field in resultFields[i])
                {
                    field.LineNum = i;
                    retFields.Add(field);
                }
            }
            fields = retFields;
            return fields;
        }

        private bool IsSameLineFields(Field f1, List<Field> f2, double prevDy = 0)
        {
            return IsSameLineFields(new List<Field> { f1 }, f2, prevDy);
        }
        private bool IsSameLineFields(List<Field> fields1, List<Field> fields2, double prevDy = 0)
        {
            if (fields2.Count == 0)
            {
                return true;
            }
            fields1.Sort((f1, f2) => f1.GetMinX().CompareTo(f2.GetMinX()));

            foreach (Field sub in fields2)
            {
                double left = Math.Max(fields1[0].GetMinX(), sub.GetMinX());
                double right = Math.Min(fields1[fields1.Count - 1].GetMaxX(), sub.GetMaxX());
                double intersect = right - left;
                double width1 = fields1[fields1.Count - 1].GetMaxX() - fields1[0].GetMinX();
                double width2 = sub.GetMaxX() - sub.GetMinX();
                if (intersect > Math.Min(width1, width2) * 0.35)
                {
                    return false;
                }
            }

            BoundingPoly targetPoly = new BoundingPoly();
            foreach (Field sub in fields1)
            {
                targetPoly.Vertices.AddRange(sub.BoundingPoly.Vertices);
            }
            BoundingPoly fieldsPoly = new BoundingPoly();
            foreach (Field sub in fields2)
            {
                fieldsPoly.Vertices.AddRange(sub.BoundingPoly.Vertices);
            }

            double intersectArea = targetPoly.GetIntersection(fieldsPoly);
            double targetArea = targetPoly.GetPolygonArea();
            if (intersectArea > targetArea * 0.8)
            {
                return true;
            }

            targetPoly.Vertices.Sort((v1, v2) => v1.X.CompareTo(v2.X));
            fieldsPoly.Vertices.Sort((v1, v2) => v1.X.CompareTo(v2.X));

            Point[] line1 = new Point[]
            {
                new Point(
                    (targetPoly.Vertices[0].X + targetPoly.Vertices[1].X) / 2,
                    (targetPoly.Vertices[0].Y + targetPoly.Vertices[1].Y) / 2
                ),
                new Point(
                    (targetPoly.Vertices[targetPoly.Vertices.Count - 1].X + targetPoly.Vertices[targetPoly.Vertices.Count - 2].X) / 2,
                    (targetPoly.Vertices[targetPoly.Vertices.Count - 1].Y + targetPoly.Vertices[targetPoly.Vertices.Count - 2].Y) / 2
                ),
            };
            double slope1 = fields1[0].Slope;
            double height1 = Math.Sqrt(
                Math.Pow(targetPoly.Vertices[0].X - targetPoly.Vertices[1].X, 2) +
                Math.Pow(targetPoly.Vertices[0].Y - targetPoly.Vertices[1].Y, 2));

            if (slope1 == 0)
            {
                slope1 = prevDy;
            }
            Point center1 = targetPoly.FindCentroid();
            double yi1 = center1.Y - (center1.X * slope1);


            Point[] line2 = new Point[]
            {
                new Point(
                    fieldsPoly.Vertices[0].X + fieldsPoly.Vertices[1].X / 2,
                    fieldsPoly.Vertices[0].Y + fieldsPoly.Vertices[1].Y / 2
                ),
                new Point(
                    fieldsPoly.Vertices[fieldsPoly.Vertices.Count - 1].X + fieldsPoly.Vertices[fieldsPoly.Vertices.Count - 2].X / 2,
                    fieldsPoly.Vertices[fieldsPoly.Vertices.Count - 1].Y + fieldsPoly.Vertices[fieldsPoly.Vertices.Count - 2].Y / 2
                ),
            };
            double slope2 = fields2[0].Slope;
            double height2 = Math.Sqrt(
                Math.Pow(fieldsPoly.Vertices[0].X - fieldsPoly.Vertices[1].X, 2) +
                Math.Pow(fieldsPoly.Vertices[0].Y - fieldsPoly.Vertices[1].Y, 2));
            if (slope2 == 0)
            {
                slope2 = prevDy;
            }
            Point center2 = fieldsPoly.FindCentroid();
            double yi2 = center2.Y - (center2.X * slope2);

            if (Math.Abs(slope1 - slope2) > 0.03)
            {
                double px = (yi2 - yi1) / (slope1 - slope2);
                double py = slope1 * px + yi1;
                if (Math.Min(line1[0].X, line2[0].X) <= px && px <= Math.Max(line1[1].X, line2[1].X))
                {
                    return true;
                }
            }

            if (fields2.Count > 1)
            {
                foreach (Field sub in fields2)
                {
                    if (IsSameLineFields(fields1, new List<Field>() { sub }))
                    {
                        return true;
                    }
                }
            }

            double d12 = Math.Abs((slope2 * center1.X) - center1.Y + yi2) / Math.Sqrt(Math.Pow(slope2, 2) + 1);
            double d21 = Math.Abs((slope1 * center2.X) - center2.Y + yi1) / Math.Sqrt(Math.Pow(slope1, 2) + 1);
            double d = Math.Max(d12, d21);
            if (d <= Math.Max(height1, height2) / 3)
            {
                return true;
            }

            return false;
        }

        public int GetFabricFormat(List<Field> poly_set, List<int> percent_indexes)
        {
            // direction is care label format
            // -1 : fabric + %
            //  1 : % + fabric

            // check fabric + % format
            var direction = -1;
            foreach (var idx in percent_indexes)
            {
                var percent_group = Regex.Matches(
                    poly_set[idx].InferText.ToLower().Replace(" ", ""),
                    @"([\p{L}]*)\s*(\d*\.?\d+\%)[^\p{L}]*([\p{L}]*)"
                ).Cast<Match>().Select(m => (
                    left: m.Groups[1].Value,
                    per: m.Groups[2].Value,
                    right: m.Groups[3].Value
                )).ToList();
                var (left, per, right) = percent_group[0];
                if (right.Length > 0)
                {
                    direction = 0;
                    break;
                }
                if (idx >= poly_set.Count - 1)
                {
                    break;
                }
                if (poly_set[idx].LineNum == poly_set[idx + 1].LineNum)
                {
                    direction = 0;
                    break;
                }
            }

            // check % + fabric format
            if (direction == 0)
            {
                direction = 1;
                foreach (var idx in percent_indexes)
                {
                    var percent_group = Regex.Matches(
                        poly_set[idx].InferText.ToLower().Replace(" ", ""),
                        @"([\p{L}]*)\s*(\d*\.?\d+\%)[^\p{L}]*([\p{L}]*)"
                    ).Cast<Match>().Select(m => (
                        left: m.Groups[1].Value,
                        per: m.Groups[2].Value,
                        right: m.Groups[3].Value
                    )).ToList();
                    var (left, per, right) = percent_group[0];
                    if (right.Length > 0)
                    {
                        continue;
                    }
                    if (idx >= poly_set.Count - 1)
                    {
                        direction = 0;
                        break;
                    }
                    if (poly_set[idx].LineNum != poly_set[idx + 1].LineNum)
                    {
                        direction = 0;
                        break;
                    }
                }
            }

            // TODO ~~~ format
            if (direction == 0)
            {
                direction = -1;
                foreach (var idx in percent_indexes)
                {
                    var percent_group = Regex.Matches(
                        poly_set[idx].InferText.ToLower().Replace(" ", ""),
                        @"([\p{L}]*)\s*(\d*\.?\d+\%)[^\p{L}]*([\p{L}]*)"
                    ).Cast<Match>().Select(m => (
                        left: m.Groups[1].Value,
                        per: m.Groups[2].Value,
                        right: m.Groups[3].Value
                    )).ToList();
                    var (left, per, right) = percent_group[0];
                    if (left.Length > 0)
                    {
                        continue;
                    }

                    if (idx == 0)
                    {
                        direction = 1;
                        break;
                    }
                    if (poly_set[idx].LineNum != poly_set[idx - 1].LineNum)
                    {
                        direction = 1;
                        break;
                    }
                }
            }
            return direction;
        }


        public List<FabricItem> MakeFabricInfo()
        {
            List<Field> needSplitField = new List<Field>();
            foreach (Field field in fields)
            {
                double slope = field.CalcSlope();
                if (slope == -20000)
                {
                    needSplitField.Add(field);
                }
            }
            fields.RemoveAll(item => item.Slope == -20000);
            foreach (Field field in needSplitField)
            {
                fields.AddRange(field.SplitFieldPoly());
            }

            fields.Sort((field1, field2) => field1.GetMinY().CompareTo(field2.GetMinY()));
            SortFields();
            SortFields();

            List<int> percent_indexes = new List<int>();
            for (int idx = 0; idx < fields.Count; idx++)
            {
                string transcription = fields[idx].InferText.Replace(" ", "");
                if (Regex.IsMatch(transcription, @"\d*.?\d+%"))
                {
                    percent_indexes.Add(idx);
                }
            }

            int direction = GetFabricFormat(fields, percent_indexes);

            List<Field> poly_set_split_per = new List<Field>();
            foreach (Field poly in fields)
            {
                Match match = Regex.Match(poly.InferText.Replace(" ", ""), @"(\d*\.?\d+\%)");
                if (!match.Success)
                {
                    poly_set_split_per.Add(poly);
                    continue;
                }

                MatchCollection percent_group = Regex.Matches(poly.InferText.ToLower().Replace(" ", ""), @"([\p{L}]*)\s*(\d*\.?\d+\%)[^\p{L}]?([\p{L}]*)");
                string left = percent_group[0].Groups[1].Value;
                string per = percent_group[0].Groups[2].Value;
                string right = percent_group[0].Groups[3].Value;

                var per_idx = poly.InferText.IndexOf(per);
                if (per_idx > 0)
                {
                    left = poly.InferText.Substring(0, per_idx);
                    right = poly.InferText.Substring(per_idx + per.Length);
                }

                if (left.Length > 0)
                {
                    Field new_poly = poly.deepClone();
                    new_poly.InferText = left;
                    poly_set_split_per.Add(new_poly);
                }

                if (per.Length > 0)
                {
                    Field new_poly = poly.deepClone();
                    new_poly.InferText = per;
                    poly_set_split_per.Add(new_poly);
                }

                if (right.Length > 0)
                {
                    Field new_poly = poly.deepClone();
                    new_poly.InferText = right;
                    poly_set_split_per.Add(new_poly);
                }
            }
            fields = poly_set_split_per;

            percent_indexes = new List<int>();
            for (int idx = 0; idx < fields.Count; idx++)
            {
                string transcription = fields[idx].InferText.Replace(" ", "");
                if (Regex.IsMatch(transcription, @"\d*.?\d+%"))
                {
                    percent_indexes.Add(idx);
                }
            }

            List<FabricItem> fabricShapeList = FilterFabricInfoToDict();
            List<FabricItem> resultFabricList = new List<FabricItem>();
            List<int> fabricList = new List<int>();

            double maxY = 0;
            double minY = int.MaxValue;

            foreach (int perIdx in percent_indexes)
            {
                MatchCollection percentGroup = Regex.Matches(fields[perIdx].InferText.Replace(" ", "").ToLower(), @"([^\d]*)(\d*\.?\d+\%)(.*)");
                string additionalText = (direction == -1) ? percentGroup[0].Groups[1].Value : percentGroup[0].Groups[3].Value;
                string fabricWord = null;
                double fabricSimilarity = 0.75;
                Field fabricPoly = null;
                string text = "";
                string originText = "";
                List<int> tempAdditionalIdxList = new List<int>();
                List<int> additionalIdxList = new List<int>();

                int additionalIdx = perIdx;
                List<Dictionary<string, object>> fabricSimList = new List<Dictionary<string, object>>();

                while (text.Length <= FabricStringUtils.MAX_FABRIC_LENGTH)
                {
                    string tempFabricWord = string.Empty;
                    double tempSimilarity = 0;
                    List<char> checkText;
                    if (direction < 0)
                    {
                        checkText = additionalText.ToCharArray().Reverse().ToList();
                    } else
                    {
                        checkText = additionalText.ToCharArray().ToList();
                    }
                    foreach (char ch in checkText)
                    {
                        if (text.Length > FabricStringUtils.MAX_FABRIC_LENGTH)
                        {
                            break;
                        }

                        if (ch == '/' || ch == '-' || ch == '·' || ch == ' ')
                        {
                            if (!string.IsNullOrWhiteSpace(fabricWord))
                            {
                                Dictionary<string, object> fabricSim = new Dictionary<string, object>();
                                fabricSim.Add("origin_text", originText);
                                fabricSim.Add("fabric_word", fabricWord);
                                fabricSim.Add("fabric_similarity", fabricSimilarity);
                                fabricSim.Add("fabric_poly", fabricPoly);
                                fabricSimList.Add(fabricSim);
                            }
                            fabricWord = null;
                            fabricSimilarity = 0.75;
                            fabricPoly = null;
                            text = "";
                            originText = "";
                            continue;
                        }

                        if (ch == '%')
                        {
                            break;
                        }

                        if (direction == -1)
                        {
                            text = ch + text;
                        }
                        else
                        {
                            text = text + ch;
                        }

                        if (text.ToLower().Contains('l'))
                        {
                            Tuple<string, double> similarFabrics = FabricStringUtils.GetSimilarFabric(text, cutoff: 0.6);
                            tempFabricWord = similarFabrics.Item1;
                            tempSimilarity = similarFabrics.Item2;

                            Tuple<string, double> similarFabrics2 = FabricStringUtils.GetSimilarFabric(text.Replace('l', 't'), cutoff: 0.6);
                            string tempFabricWord2 = similarFabrics2.Item1;
                            double tempSimilarity2 = similarFabrics2.Item2;

                            if (tempSimilarity < tempSimilarity2)
                            {
                                tempFabricWord = tempFabricWord2;
                                tempSimilarity = tempSimilarity2;
                            }

                            if (tempSimilarity > fabricSimilarity)
                            {
                                fabricWord = tempFabricWord;
                                fabricSimilarity = tempSimilarity;
                                originText = text;
                                //TODO implements match_fabric_points()
                                fabricPoly = fields[perIdx];
                            }
                        }
                        else
                        {
                            Tuple<string, double> similarFabrics = FabricStringUtils.GetSimilarFabric(text, cutoff: 0.6);
                            tempFabricWord = similarFabrics.Item1;
                            tempSimilarity = similarFabrics.Item2;
                        }

                        if (tempSimilarity >= fabricSimilarity)
                        {
                            originText = text;
                            fabricWord = tempFabricWord;
                            fabricSimilarity = tempSimilarity;
                            //TODO implements match_fabric_points()
                            fabricPoly = fields[perIdx];
                            additionalIdxList.AddRange(tempAdditionalIdxList);
                        }
                    }
                    additionalIdx += direction;

                    if (additionalIdx >= fields.Count || additionalIdx < 0 ||
                        Math.Abs(fields[perIdx].LineNum - fields[additionalIdx].LineNum) > 1 ||
                        (additionalIdx != perIdx && percent_indexes.Contains(additionalIdx)))
                    {
                        break;
                    }
                    tempAdditionalIdxList.Add(additionalIdx);
                    additionalText = fields[additionalIdx].InferText;
                }

                if (fabricWord != null)
                {
                    fabricSimList.Add(new Dictionary<string, object> {
                        {"origin_text", originText},
                        {"fabric_word", fabricWord},
                        {"fabric_similarity", fabricSimilarity},
                        {"fabric_poly", fabricPoly}
                    });
                }

                fabricSimList = fabricSimList.Where(fabric_sim =>
                    !fabric_sim["origin_text"].ToString().ToLower().Contains("bambak") &&
                    !fabric_sim["origin_text"].ToString().ToLower().Contains("algod") &&
                    !fabric_sim["origin_text"].ToString().ToLower().Contains("san")
                ).ToList();

                var eng_sim_list = new List<Dictionary<string, object>>();
                var kor_sim_list = new List<Dictionary<string, object>>();
                foreach (var fabric_sim in fabricSimList)
                {
                    if (!System.Text.RegularExpressions.Regex.IsMatch(fabric_sim["origin_text"].ToString(), @"^[a-zA-Z0-9]+$"))
                    {
                        kor_sim_list.Add(fabric_sim);
                        continue;
                    }
                    eng_sim_list.Add(fabric_sim);
                }

                fabricSimList = kor_sim_list;
                if (eng_sim_list.Any())
                {
                    eng_sim_list.Sort((a, b) => -1 * a["fabric_similarity"].ToString().CompareTo(b["fabric_similarity"].ToString()));
                    fabricSimList.Add(eng_sim_list[0]);
                }

                foreach (var fabric_sim in fabricSimList)
                {
                    if (fabric_sim["fabric_word"] != null)
                    {
                        var fabric_item = new FabricItem(
                            fabric_sim["fabric_word"].ToString(),
                            fabric_sim["origin_text"].ToString(),
                            percentGroup[0].Groups[2].Value,
                            fields[tempAdditionalIdxList.Any() ? tempAdditionalIdxList[0] : perIdx],
                            tempAdditionalIdxList.Any() ? tempAdditionalIdxList[0] : perIdx,
                            Double.Parse(fabric_sim["fabric_similarity"].ToString()),
                            tempAdditionalIdxList);
                        resultFabricList.Add(fabric_item);
                        fabricList.AddRange(additionalIdxList);
                        //if (!fabricList.Contains(perIdx))
                        //{
                        //    fabricList.Add(perIdx);
                        //}
                    }
                }

                maxY = Math.Max(fields[perIdx].GetMaxY(), maxY);
                minY = Math.Min(fields[perIdx].GetMinY(), minY);
            }

            // y-axis 기준 범위 over 한 list 제외
            if ( maxY == 0 )
            {
                minY = 0;
                maxY = int.MaxValue;
            }
            List<FabricItem> remain_fabric_list = new List<FabricItem>();
            fabricShapeList.Sort((item1, item2) =>
            Math.Abs(item1.Poly.GetMinY() - ((maxY + minY) / 2)).CompareTo(
            Math.Abs(item2.Poly.GetMinY() - ((maxY + minY) / 2))
            )
            );
            if (fabricShapeList.Count > 0)
            {
                foreach (var fabric_shape in fabricShapeList)
                {
                    int fabric_shape_idx = fabric_shape.Index;;
                    Field poly = fabric_shape.Poly;

                    bool isContains = false;
                    foreach(int idx in fabric_shape.IndexList)
                    {
                        if (fabricList.Contains(idx))
                        {
                            isContains = true;
                            break;
                        }
                    }

                    if (!isContains &&
                    maxY + (poly.GetHeight() / 2) >= poly.GetMinY() &&
                    poly.GetMaxY() >= Math.Max(minY - (poly.GetHeight() * 2 / 3), 0))
                    {
                        resultFabricList.Add(fabric_shape);

                        maxY = Math.Max(maxY, poly.GetMaxY());
                        minY = Math.Min(minY, poly.GetMinY());
                    }
                    else if (!fabricList.Contains(fabric_shape_idx))
                    {
                        remain_fabric_list.Add(fabric_shape);
                    }
                }
            }

            bool isExistCotton = false;

            foreach (var fabricShape in resultFabricList)
            {
                if (fabricShape.OriginLabel.Contains("면") || fabricShape.OriginLabel.ToLower().Contains("cotton"))
                {
                    isExistCotton = true;
                }
            }

            FabricItem cottonShape = null;
            foreach (var fabricShape in resultFabricList)
            {
                if (fabricShape.OriginLabel.ToLower() == "coton")
                {
                    cottonShape = fabricShape;
                    break;
                }
            }

            resultFabricList = resultFabricList.Where(fabricShape => fabricShape.OriginLabel.ToLower() != "coton").ToList();
            if (!isExistCotton && cottonShape != null)
            {
                resultFabricList.Add(cottonShape);
            }

            List<int> needRemoveIdxList = new List<int>();
            int polyesterCnt = 0;
            int headIdx = 0;
            for (int i = 0; i < resultFabricList.Count; i++)
            {
                var fabric = resultFabricList[i];
                //if ("polyester" in fabric["origin_label"].lower())
                if (fabric.Label.Contains("폴리에스터"))
                {
                    polyesterCnt += 1;
                }

                if (fabric.Label.Contains("폴리에스터") && fabric.OriginLabel.ToString().All(char.IsLetterOrDigit))
                {
                    int polyIdx = Convert.ToInt32(fabric.Index);
                    int polyLineNum = fields[polyIdx].LineNum;
                    if (polyLineNum == 0)
                    {
                        headIdx = 0;
                    }
                    else
                    {
                        headIdx = polyIdx;
                        for (int idx = polyIdx; idx > 0; idx--)
                        {
                            if (polyLineNum == fields[idx].LineNum)
                            {
                                headIdx = idx;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    string headText = fields[headIdx].InferText;
                    bool ignore = false;
                    foreach (string IgnoreCountryCode in FabricStringUtils.fabricData.IgnoreCountryCodeList)
                    {
                        if (headText.StartsWith(IgnoreCountryCode))
                        {
                            needRemoveIdxList.Add(i);
                            ignore = true;
                            break;
                        }
                    }
                    if (ignore)
                    {
                        continue;
                    }

                    if (polyLineNum < 1)
                    {
                        continue;
                    }
                    for (int idx = polyIdx; idx > 0; idx--)
                    {
                        if (polyLineNum - 1 <= fields[idx].LineNum)
                        {
                            headIdx = idx;
                        }
                        else
                        {
                            break;
                        }
                    }
                    headText = fields[headIdx].InferText;
                    foreach (string IgnoreCountryCode in FabricStringUtils.fabricData.IgnoreCountryCodeList)
                    {
                        if (headText.StartsWith(IgnoreCountryCode))
                        {
                            needRemoveIdxList.Add(i);
                            ignore = true;
                            break;
                        }
                    }
                    if (ignore)
                    {
                        continue;
                    }
                }
            }

            if (polyesterCnt > 0 && polyesterCnt == needRemoveIdxList.Count)
            {
                needRemoveIdxList.RemoveAt(0);
            }

            List<FabricItem> resultFabricListNew = new List<FabricItem>();
            for (int idx = 0; idx < resultFabricList.Count; idx++)
            {
                if (!needRemoveIdxList.Contains(idx))
                {
                    resultFabricListNew.Add(resultFabricList[idx]);
                }
            }
            resultFabricList = resultFabricListNew;

            if (resultFabricList.Count > 0)
            {
                resultFabricList = RemoveOutlier(resultFabricList, epsiloneRatio: 3);
                foreach (FabricItem resultFabric in resultFabricList)
                {
                    resultFabric.Outlier = true;
                }
            }

            // 0037_2 case
            // poliester is not ENG
            bool isExistPolyester = false;
            foreach (var fabric in resultFabricList)
            {
                if (fabric.OriginLabel.ToString().ToLower().Contains("polyester"))
                {
                    isExistPolyester = true;
                    break;
                }
            }

            if (isExistPolyester)
            {
                List<FabricItem> resultFabricListNew2 = new List<FabricItem>();
                foreach (FabricItem fabric in resultFabricList)
                {
                    if (!fabric.OriginLabel.ToString().ToLower().Contains("poliester"))
                    {
                        resultFabricListNew2.Add(fabric);
                    }
                }
                resultFabricList = resultFabricListNew2;
            }

            resultFabricList = resultFabricList.Where(fabricShape => fabricShape.OriginLabel.ToLower() != "조성섬유").ToList();
            resultFabricList = resultFabricList.Where(fabricShape => !fabricShape.Poly.InferText.ToLower().Contains("모자")).ToList();
            resultFabricList = resultFabricList.Where(fabricShape => !fabricShape.Poly.InferText.ToLower().Contains("pant")).ToList();

            return resultFabricList;
        }

        public static List<FabricItem> RemoveOutlier(List<FabricItem> fabricList, int epsiloneRatio = 4)
        {
            if (fabricList.Count < 2)
            {
                return fabricList;
            }

            fabricList.Sort((x, y) =>
            {
                return x.Poly.CenterPoint.Y.CompareTo(y.Poly.CenterPoint.Y);
            });

            double hSum = fabricList.Average(x =>
            {
                return x.Poly.GetMaxY() - x.Poly.GetMinY();
            });

            double epsilon = hSum * epsiloneRatio;
            List<List<FabricItem>> group = new List<List<FabricItem>>() { new List<FabricItem>() { fabricList[0] } };

            for (int i = 1; i < fabricList.Count; i++)
            {
                var prevY = group.Last().Last().Poly.CenterPoint.Y;
                var curY = fabricList[i].Poly.CenterPoint.Y;
                var isNeighbor = (curY - prevY) < epsilon;
                if (isNeighbor)
                {
                    group.Last().Add(fabricList[i]);
                }
                else
                {
                    group.Add(new List<FabricItem>() { fabricList[i] });
                }
            }

            int maxLenOfGroup = group.Max(x => x.Count);

            if (maxLenOfGroup > 1)
            {
                fabricList = new List<FabricItem>();
                foreach (var items in group)
                {
                    if (items.Count == maxLenOfGroup)
                    {
                        fabricList.AddRange(items);
                    }
                    else
                    {
                        foreach (FabricItem item in items)
                        {
                            if (item.Outlier)
                            {
                                fabricList.Add(item);
                            }
                        }
                    }
                }
            }

            return fabricList;
        }

        public List<FabricItem> FilterFabricInfoToDict()
        {
            if (fields == null || !fields.Any())
                return new List<FabricItem>();

            string fullString = "";
            List<int> idxMap = new List<int>();
            for (int i = 0; i < fields.Count(); i++)
            {
                Field poly = fields[i];
                string transcription = poly.InferText.Replace(" ", "");
                fullString += transcription;
                for (int j = 0; j < transcription.Length; j++)
                {
                    idxMap.Add(i);
                }
            }

            List<Tuple<string, string, int, int>> matchFabrics = FabricStringUtils.GetFabricWord(fullString);

            List<FabricItem> resultFabricList = new List<FabricItem>();
            for (int i = 0; i < matchFabrics.Count(); i++)
            {
                List<int> usedIdx = new List<int>();
                Tuple<string, string, int, int> matchFabric = matchFabrics[i];
                if (matchFabric.Item2 == "!" || string.IsNullOrEmpty(matchFabric.Item2))
                {
                    continue;
                }

                Field currentPoly = fields[idxMap[matchFabric.Item3]];

                string percentText = null;
                int[] rng = { 0, matchFabric.Item3 };
                int prevIdx = 0;
                if (i > 0)
                {
                    prevIdx = matchFabrics[i - 1].Item4;
                }
                for (int temp = matchFabric.Item3; temp > prevIdx - 1; temp--)
                {
                    if (usedIdx.Contains(temp))
                    {
                        break;
                    }
                    rng[0] = temp;
                }

                MatchCollection percentIter = Regex.Matches(fullString.Substring(rng[0], rng[1] - rng[0]), @"(\d*\.?\d+\%)");
                foreach (Match item in percentIter)
                {
                    Field percentPoly = fields[idxMap[rng[0] + item.Index]];
                    if (currentPoly.LineNum != percentPoly.LineNum)
                    {
                        continue;
                    }

                    percentText = item.Value;
                    for (int temp = item.Index; temp < item.Index + item.Length; temp++)
                    {
                        usedIdx.Add(rng[0] + temp);
                    }
                    break;
                }

                if (percentText == null)
                {
                    rng = new int[] { matchFabric.Item4, matchFabric.Item4 };

                    int nextIdx = fullString.Length;
                    if (i < matchFabrics.Count() - 2)
                    {
                        nextIdx = matchFabrics[i + 1].Item3;
                    }

                    for (int temp = matchFabric.Item4; temp < nextIdx + 1; temp++)
                    {
                        if (usedIdx.Contains(temp))
                        {
                            break;
                        }
                        rng[1] = temp;
                    }

                    percentIter = Regex.Matches(fullString.Substring(rng[0], rng[1] - rng[0]), @"(\d*\.?\d+\%)");
                    foreach (Match item in percentIter)
                    {
                        Field percentPoly = fields[idxMap[rng[0] + item.Index]];
                        if (currentPoly.LineNum != percentPoly.LineNum)
                        {
                            continue;
                        }

                        percentText = item.Value;
                        for (int temp = item.Index; temp < item.Index + item.Length; temp++)
                        {
                            if (!usedIdx.Contains(rng[0] + temp))
                            {
                                usedIdx.Add(rng[0] + temp);
                            }
                        }
                        break;
                    }
                }

                for (int idx = matchFabric.Item3; idx < matchFabric.Item4; idx++)
                {
                    if (!usedIdx.Contains(idx))
                    {
                        usedIdx.Add(idx);
                    }
                }

                if (string.IsNullOrEmpty(percentText))
                {
                    percentText = "0%";
                }

                List<int> usedFieldIdx = new List<int>();
                foreach (int strIdx in usedIdx)
                {
                    if (!usedFieldIdx.Contains(idxMap[strIdx]))
                    {
                        usedFieldIdx.Add(idxMap[strIdx]);
                    }
                }

                FabricItem fabricItem = new FabricItem(matchFabric.Item2, matchFabric.Item1, percentText, this.fields[idxMap[matchFabric.Item3]], idxMap[matchFabric.Item3], indexList: usedFieldIdx);
                resultFabricList.Add(fabricItem);
            }

            return resultFabricList;
        }

        public FabricFinder(List<Field> fields)
        {
            this.fields = fields;
        }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            int prevLineNum = 0;

            foreach (Field field in this.fields)
            {
                if (field.LineNum != prevLineNum)
                {
                    result.AppendLine();
                    prevLineNum = field.LineNum;
                }

                result.Append(field.InferText);
            }

            return result.ToString();
        }
    }
}
