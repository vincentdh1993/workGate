﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ScanToStyleCS.FabricExtractor.OcrEngine;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ScanToStyleCS.FabricExtractor.ClovaOcrEngine
{
    public class ClovaOcrEngine
    {
        // OCR 엔진에 접근할 때 사용할 비밀 키
        private readonly string _secretKey;
        // OCR 엔진의 URL
        private readonly string _url;
        // OCR결과를 저장할 path.
        public string SavedPath { get; set; }

        /// <summary>
        /// ClovaOcrEngine 클래스의 새 인스턴스를 생성합니다.
        /// </summary>
        /// <param name="secretKey">OCR 엔진에 접근할 때 사용할 비밀 키</param>
        /// <param name="url">OCR 엔진의 URL</param>
        /// <param name="savePath">[option] OCR결과 json을 저장할 디렉토리</param>
        public ClovaOcrEngine(string secretKey, string url, string savePath = "")
        {
            _secretKey = secretKey;
            _url = url;
            SavedPath = savePath;
        }

        /// <summary>
        /// 이미지에서 텍스트를 인식합니다.
        /// </summary>
        /// <param name="image">인식할 이미지</param>
        /// <returns>인식된 텍스트의 결과</returns>
        public OcrResultItem RecognizeText(Image image)
        {
            var request = (HttpWebRequest)WebRequest.Create(_url);
            request.Headers.Add("X-OCR-SECRET", _secretKey);
            request.Method = "POST";
            request.ContentType = "application/json; utf-8";

            var body = new OcrRequestBodyModel(image);
            var bodyJson = JsonConvert.SerializeObject(body);

            using (var streamWriter = new StreamWriter(request.GetRequestStream()))
            {
                streamWriter.Write(bodyJson);
            }

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                using (var streamReader = new StreamReader(response.GetResponseStream()))
                {
                    var apiResult = streamReader.ReadToEnd();
                    SaveImageAndJson(image, body.Timestamp.ToString(), apiResult);
                    return JsonConvert.DeserializeObject<OcrResultItem>(apiResult);
                }
            }
        }

        /// <summary>
        /// OCR 요청시 사용한 이미지와 json결과를 저장합니다.
        /// SavedPath가 비어있으면 저장하지 않습니다.
        /// </summary>
        /// <param name="image">OCR API 요청시 사용한 이미지</param>
        /// <param name="filename">저장할 파일 이름</param>
        /// <param name="apiResult">ocr 결과</param>
        private void SaveImageAndJson(Image image, string filename, string apiResult)
        {
            if (!string.IsNullOrEmpty(SavedPath))
            {
                DirectoryInfo di = new DirectoryInfo(SavedPath);
                if (!di.Exists) { di.Create(); }

                string _savePath = Path.Combine(SavedPath, filename);
                image.Save($"{_savePath}.bmp");
                File.WriteAllText($"{_savePath}.json", apiResult, Encoding.UTF8);
            }
        }
    }
}