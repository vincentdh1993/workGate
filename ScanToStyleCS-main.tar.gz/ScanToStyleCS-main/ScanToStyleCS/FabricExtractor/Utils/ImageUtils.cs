﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScanToStyleCS.FabricExtractor.Utils
{
    public static class ImageUtils
    {
        public static String ImgToB64String(Image input)
        {
            using (var ms = new MemoryStream())
            {
                input.Save(ms, ImageFormat.Png);
                return Convert.ToBase64String(ms.ToArray());
            }
        }

        public static long FindScore(Bitmap arr, int angle)
        {
            using (Bitmap data = RotateImage(arr, angle))
            {
                //int height = data.Height;
                //int width = data.Width;
                int height = arr.Height;
                int width = arr.Width;
                int inity = (data.Height - arr.Height) / 2;
                int initx = (data.Width - arr.Width) / 2;

                int[] hist = new int[height];
                Bitmap temp = (Bitmap)data.Clone();
                BitmapData bitmapData = data.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, data.PixelFormat);
                int bytesPerPixel = Bitmap.GetPixelFormatSize(data.PixelFormat) / 8;
                int stride = bitmapData.Stride;
                IntPtr scan0 = bitmapData.Scan0;

                unsafe
                {
                    byte* ptr = (byte*)(void*)scan0;

                    for (int y = inity; y < height; y++)
                    {
                        int pixelSum = 0;
                        for (int x = initx; x < width; x++)
                        {
                            int pixel = ptr[x * bytesPerPixel];
                            pixelSum += pixel;
                        }
                        hist[y] = pixelSum;
                        ptr += stride;
                    }
                }

                data.UnlockBits(bitmapData);

                long score = 0;
                for (int i = 1; i < hist.Length; i++)
                {
                    int diff = hist[i] - hist[i - 1];
                    score += diff * diff;
                }
                return score;
            }
        }

        public static Bitmap RotateImage(Bitmap image, float angle)
        {
            float radians = angle * (float)Math.PI / 180f;
            float cos = (float)Math.Cos(radians);
            float sin = (float)Math.Sin(radians);

            int width = (int)Math.Round(image.Width * Math.Abs(cos) + image.Height * Math.Abs(sin));
            int height = (int)Math.Round(image.Height * Math.Abs(cos) + image.Width * Math.Abs(sin));

            Bitmap rotatedImage = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(rotatedImage))
            {
                g.TranslateTransform(width / 2f, height / 2f);
                g.RotateTransform(angle);
                g.TranslateTransform(-image.Width / 2f, -image.Height / 2f);
                g.DrawImage(image, 0, 0);
            }

            return rotatedImage;
        }

        public static int GetRotateAngle(string filename, double fixedWidth = 300.0)
        {
            Bitmap img = new Bitmap(filename);
            return GetRotateAngle(img, fixedWidth);
        }

        private static Bitmap AdaptiveThreshold(Bitmap image, int thresholdMax, int blockSize, double k)
        {
            int width = image.Width;
            int height = image.Height;
            int halfBlockSize = blockSize / 2;

            Bitmap output = (Bitmap)image.Clone();
            BitmapData imageData = image.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            BitmapData outputData = output.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);

            int stride = imageData.Stride;
            int bytesPerPixel = 3;
            IntPtr scan0 = imageData.Scan0;
            IntPtr scan1 = outputData.Scan0;

            unsafe
            {
                byte* p = (byte*)(void*)scan0;
                byte* o = (byte*)(void*)scan1;

                for (int y = 0; y < height; y++)
                {
                    int yStart = Math.Max(0, y - halfBlockSize);
                    int yEnd = Math.Min(height - 1, y + halfBlockSize);

                    for (int x = 0; x < width; x++)
                    {
                        int xStart = Math.Max(0, x - halfBlockSize);
                        int xEnd = Math.Min(width - 1, x + halfBlockSize);

                        int sum = 0;

                        for (int j = yStart; j <= yEnd; j++)
                        {
                            byte* row = p + (j * stride);

                            for (int i = xStart; i <= xEnd; i++)
                            {
                                byte* pixel = row + (i * bytesPerPixel);
                                int pixelValue = (int)(0.299 * pixel[2] + 0.587 * pixel[1] + 0.114 * pixel[0]);
                                sum += pixelValue;
                            }
                        }

                        int count = (xEnd - xStart + 1) * (yEnd - yStart + 1);
                        int threshold = (int)((sum / count) - k);

                        threshold = Math.Min(thresholdMax, Math.Max(0, threshold));

                        byte* outputPixel = o + (y * stride) + (x * bytesPerPixel);
                        int outputValue = (int)(0.299 * outputPixel[2] + 0.587 * outputPixel[1] + 0.114 * outputPixel[0]);

                        if (outputValue > threshold)
                        {
                            outputPixel[0] = 0;
                            outputPixel[1] = 0;
                            outputPixel[2] = 0;
                        }
                        else
                        {
                            outputPixel[0] = 255;
                            outputPixel[1] = 255;
                            outputPixel[2] = 255;
                        }
                    }
                }
            }

            output.UnlockBits(outputData);

            return output;
        }

        private static Bitmap GaussianBlur(Bitmap image, double sigma = 1.4, int size = 3)
        {
            int width = image.Width;
            int height = image.Height;

            Bitmap output = new Bitmap(width, height);

            // Gaussian kernel generation
            double[,] kernel = new double[size, size];
            double sum = 0.0;
            for (int x = 0; x < size; x++)
            {
                for (int y = 0; y < size; y++)
                {
                    double val = Math.Exp(-0.5 * ((x * x + y * y) / (sigma * sigma))) / (2 * Math.PI * sigma * sigma);
                    kernel[x, y] = val;
                    sum += val;
                }
            }
            // Normalize kernel values
            for (int x = 0; x < size; x++)
            {
                for (int y = 0; y < size; y++)
                {
                    kernel[x, y] /= sum;
                }
            }

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    double r = 0.0, g = 0.0, b = 0.0;
                    for (int i = -size / 2; i <= size / 2; i++)
                    {
                        for (int j = -size / 2; j <= size / 2; j++)
                        {
                            int xIndex = x + i;
                            int yIndex = y + j;
                            if (xIndex < 0) xIndex = 0;
                            if (xIndex >= width) xIndex = width - 1;
                            if (yIndex < 0) yIndex = 0;
                            if (yIndex >= height) yIndex = height - 1;

                            Color pixelColor = image.GetPixel(xIndex, yIndex);
                            r += kernel[i + size / 2, j + size / 2] * pixelColor.R;
                            g += kernel[i + size / 2, j + size / 2] * pixelColor.G;
                            b += kernel[i + size / 2, j + size / 2] * pixelColor.B;
                        }
                    }
                    Color outputColor = Color.FromArgb((int)r, (int)g, (int)b);
                    output.SetPixel(x, y, outputColor);
                }
            }
            return output;
        }


        public static int GetRotateAngle(Bitmap img, double fixedWidth = 300.0)
        {
            int height = img.Height;
            int width = img.Width;

            double scale = (double)fixedWidth / width;
            width = (int)(width * scale);
            height = (int)(height * scale);

            Bitmap resizeImg = new Bitmap(img, new Size(width, height));
            //Bitmap blurImg = GaussianBlur(resizeImg, 3, 3);
            Bitmap thresholdImg = AdaptiveThreshold(resizeImg, 255, 9, 10);
            resizeImg.Dispose();

            int delta = 1;
            int limit = 45;
            List<long> angles = new List<long>();
            for (int angle = -limit; angle <= limit; angle += delta)
            {
                long result = FindScore(thresholdImg, angle);
                angles.Add(result);
            }

            long bestScore = angles.Max();
            int bestAngle = angles.IndexOf(bestScore) - limit;

            thresholdImg.Dispose();
            return bestAngle;
        }

    }
}
