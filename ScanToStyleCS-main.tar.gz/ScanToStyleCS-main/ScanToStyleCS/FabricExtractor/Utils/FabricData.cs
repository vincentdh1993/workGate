﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScanToStyleCS.FabricExtractor
{
    public class FabricData
    {
        public Dictionary<string, string> FabricSynonymData { get; set; }
        public List<string> FabricDataList { get; set; }
        public List<string> IgnoreCountryCodeList { get; set; }
        public Dictionary<string, string> FabricWordDict { get; set; }
        public List<string> FabricWordList { get; set; }
        public Dictionary<char, Dictionary<char, float>> CharSimScoreList { get; set; }

        public int LineNumber { get; set; } = 0;

        public double Slope { get; set; } = .0f;

    }
}
