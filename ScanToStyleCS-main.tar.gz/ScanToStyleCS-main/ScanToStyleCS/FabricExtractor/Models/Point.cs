﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScanToStyleCS.FabricExtractor.OcrEngine.Models
{
    public class Point
    {
        [JsonProperty("x")]
        public double X { get; set; } = .0f;
        [JsonProperty("y")]
        public double Y { get; set; } = .0f;

        public Point(double x, double y)
        {
            this.X = x;
            this.Y = y;
        }

        public override string ToString()
        {
            return $"{X} {Y}";
        }
    }
}
