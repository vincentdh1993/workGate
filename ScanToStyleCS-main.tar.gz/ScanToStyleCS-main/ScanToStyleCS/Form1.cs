﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.ML.OnnxRuntime;
using Newtonsoft.Json;
using ScanToStyleCS.FabricExtractor.ClovaOcrEngine;
using ScanToStyleCS.FabricExtractor.Models;

namespace ScanToStyleCS
{
    public partial class Form1 : Form
    {
        CareLabelAnalyzer careLabelAnalyzer;
        public Form1()
        {
            InitializeComponent();

            string[] fileEntries = Directory.GetFiles("DemoImages");
            foreach (string file in fileEntries)
            {
                if (!Path.GetFileName(file).EndsWith(".jpg"))
                {
                    continue;
                }
                var item = new System.Windows.Forms.ToolStripMenuItem()
                {
                    Name = file,
                    Text = Path.GetFileName(file)
                };
                item.Click += new EventHandler((sender, e)=> LoadInferenceImage(file));
                demoToolStripMenuItem.DropDownItems.Add(item);
            }

            string ocrJsonText = System.IO.File.ReadAllText("SecretKeyAndAPIGW.json");
            Dictionary<string, string> ocrInfo = JsonConvert.DeserializeObject<Dictionary<string, string>>(ocrJsonText);
            careLabelAnalyzer = new CareLabelAnalyzer(ocrInfo["SecretKey"], ocrInfo["API_GW"], ocrInfo["SaveResultPath"]);
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string image_file = string.Empty;
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.InitialDirectory = @"C:\";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                LoadInferenceImage(dialog.FileName);
                return;
            }
            else if (dialog.ShowDialog() == DialogResult.Cancel)
            {
                return;
            }
        }

        public Bitmap LoadBitmap(string path)
        {
            if (File.Exists(path))
            {
                // open file in read only mode
                using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read))
                // get a binary reader for the file stream
                using (BinaryReader reader = new BinaryReader(stream))
                {
                    // copy the content of the file into a memory stream
                    var memoryStream = new MemoryStream(reader.ReadBytes((int)stream.Length));
                    // make a new Bitmap object the owner of the MemoryStream
                    return new Bitmap(memoryStream);
                }
            }
            else
            {
                MessageBox.Show("Error Loading File.", "Error!", MessageBoxButtons.OK);
                return null;
            }
        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;
        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            LoadInferenceImage(files[0]);
        }


        public void LoadInferenceImage(string image_file)
        {
            imageBox.Image = LoadBitmap(image_file);
            this.tbResult.Text = "";

            Image image = imageBox.Image;

            CareLabelAnalyzer.ResultCareLabelAnalysis result = careLabelAnalyzer.AnalyzeImage(image);

            this.tbResult.Text += $"{result.RotateDegrees} Rotated\r\n";
            this.imageBox.Image = result.RotatedImage;

            // draw result
            Graphics graphics = Graphics.FromImage(imageBox.Image);
            foreach (SymbolPrediction prediction in result.SymbolList)
            {
                double score = Math.Round(prediction.Score, 2);
                graphics.DrawRectangles(new Pen(prediction.Label.Color, imageBox.Image.Width / 300), new[] { prediction.Rectangle });

                var (x, y) = (prediction.Rectangle.X - 3, prediction.Rectangle.Y - 23);

                graphics.DrawString
                (
                    $"{prediction.Label.Name} ({score})",
                    new Font("Consolas", imageBox.Image.Width / 40, GraphicsUnit.Pixel),
                    new SolidBrush(Color.Red),
                    new PointF(x, y)
                );
                this.tbResult.Text += $"{prediction.Label.Name} ({score})\r\n";
            }

            this.tbResult.Text += "\r\n";
            foreach (FabricItem fabricItem in result.FabricItemList)
            {
                graphics.DrawRectangles(new Pen(Color.Green, imageBox.Image.Width / 300), new[] { RectangleF.FromLTRB((float)fabricItem.Poly.GetMinX(), (float)fabricItem.Poly.GetMinY(), (float)fabricItem.Poly.GetMaxX(), (float)fabricItem.Poly.GetMaxY()) });

                this.tbResult.Text += $"{fabricItem.Label} ({fabricItem.Percent})\r\n";
            }
            this.tbResult.Text += "\r\n";
            this.tbResult.Text += result.LabelText;
        }
    }
}
