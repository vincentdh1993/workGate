﻿using Newtonsoft.Json;
using ScanToStyleCS.FabricExtractor.OcrEngine;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ScanToStyleCS
{
    static class Program
    {
        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();
        /// <summary>
        /// 해당 애플리케이션의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                string path = args[0];
                if (path.Contains(".json"))
                {
                    string jsonText = System.IO.File.ReadAllText(path);
                    OcrResultItem ocrResult = JsonConvert.DeserializeObject<OcrResultItem>(jsonText);
                    FabricFinder fabricFinder = new FabricFinder(ocrResult.Images[0].Fields);
                    List<FabricExtractor.Models.FabricItem> result = fabricFinder.MakeFabricInfo();
                    string strJson = JsonConvert.SerializeObject(result);
                    Console.WriteLine(strJson);
                }
                else
                {
                    SymbolDetector<YOLOV8Model> scorer = new SymbolDetector<YOLOV8Model>("CareSymbolDetector/Weight/yolov8-s.onnx");
                    Bitmap bitmap = new Bitmap(path);
                    List<SymbolPrediction> result = scorer.Predict(bitmap);
                    string strJson = JsonConvert.SerializeObject(result);
                    Console.WriteLine(strJson);
                }
                return;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
