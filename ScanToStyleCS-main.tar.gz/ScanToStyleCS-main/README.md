# ScanToStyleCS
이미지에서 세탁기호 정보와 섬유명 정보를 추출합니다.
![image](examples/result.png)


## Getting started
OCR기능은 CLOVA OCR API를 사용합니다.    
https://www.ncloud.com/product/aiService/ocr 를 통해 이용신청하여야 합니다.   
비용은 100건까지 무료 이후 건당 3원이 청구됩니다.   
   
신청이후 OCR general domain의 SecretKey와 api 게이트웨이 url이 필요하며,  
ScanToStyleCS/SecretKeyAndAPIGW.json 에 입력 필요합니다.  


```json
{
  "SecretKey": "ZEtwcXBsbk▚▚▚▚NZQ3plck1IaEVxaUVTSlFSVWRqZVY=",
  "API_GW": "https://1553d0eb0▚▚▚4cea88e5e5460a8c0fc0.apigw.ntruss.com/custom/v1/10137/4e54907646fe2aa03e2ff2fd31f33efa▚▚▚4ec52c52b37df831c3ab6c097161b/general",
  "SaveResultPath": "c:\\ResultCareOCR\\"
}
```