﻿using System.Drawing;

namespace LaundrySolution.ScanToStyleCS
{
    /// <summary>
    /// YOLO 레이블
    /// </summary>
    public class SymbolLabel
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////// Property
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region ID - ID

        /// <summary>
        /// ID
        /// </summary>
        public int ID { get; set; }

        #endregion
        #region 명칭 - Name

        /// <summary>
        /// 명칭
        /// </summary>
        public string Name { get; set; }

        #endregion
        #region 종류 - Kind

        /// <summary>
        /// YOLO 레이블 종류
        /// </summary>
        public SymbolLabelKind Kind { get; set; }

        #endregion
        #region 색상 - Color

        /// <summary>
        /// 색상
        /// </summary>
        public Color Color { get; set; }

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Constructor
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 생성자 - YOLOLabel()

        /// <summary>
        /// 생성자
        /// </summary>
        public SymbolLabel()
        {
            Color = Color.Yellow;
        }

        #endregion
    }
}