﻿using System.Drawing;

namespace LaundrySolution.ScanToStyleCS
{
    /// <summary>
    /// 사각형 확장
    /// </summary>
    public static class RectangleExtension
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////// Method
        ////////////////////////////////////////////////////////////////////////////////////////// Static
        //////////////////////////////////////////////////////////////////////////////// Public

        #region 영역 구하기 - GetArea(rectangle)

        /// <summary>
        /// 영역 구하기
        /// </summary>
        /// <param name="rectangle">사각형</param>
        /// <returns>영역</returns>
        public static float GetArea(this RectangleF rectangle)
        {
            return rectangle.Width * rectangle.Height;
        }

        #endregion
    }
}