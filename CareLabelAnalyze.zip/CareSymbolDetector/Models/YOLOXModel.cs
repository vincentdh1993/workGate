﻿using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace LaundrySolution.ScanToStyleCS
{
    /// <summary>
    /// YOLOX CareSymbol Model
    /// </summary>
    public class YOLOXModel: SymbolModel
    {

        #region 너비 - Width

        /// <summary>
        /// 너비
        /// </summary>
        public override int Width { get; set; } = 640;

        #endregion
        #region 높이 - Height

        /// <summary>
        /// 높이
        /// </summary>
        public override int Height { get; set; } = 640;
        #endregion

        #region 인풋 Color 형식 enum class
        public override ColorField InputColor { get; set; } = ColorField.RgbLong;
        #endregion

        #region Label 갯수 - LabelCount

        /// <summary>
        /// 차원
        /// </summary>
        public override int LabelCount { get; set; } = 40;

        #endregion


        #region 신뢰도 - Confidence

        /// <summary>
        /// 신뢰도
        /// </summary>
        public override float Confidence { get; set; } = 0.20f;

        #endregion

        #region 오버랩 - Overlap

        /// <summary>
        /// 오버랩
        /// </summary>
        public override float Overlap { get; set; } = 0.45f;

        #endregion
        #region 출력 배열 - OutputArray

        /// <summary>
        /// 출력 배열
        /// </summary>
        public override string[] OutputArray { get; set; } = new[] { "boxes", "scores" };

        #endregion
        #region 레이블 리스트 - LabelList

        /// <summary>
        /// 레이블 리스트
        /// </summary>
        public override List<SymbolLabel> LabelList { get; set; } = new List<SymbolLabel>()
        {
            new SymbolLabel { ID = 1, Name = "bleach-jp_do"             },
            new SymbolLabel { ID = 2, Name = "bleach-jp_do-not"         },
            new SymbolLabel { ID = 3, Name = "bleach_do"                },
            new SymbolLabel { ID = 4, Name = "bleach_do-not"            },
            new SymbolLabel { ID = 5, Name = "dry-clean-kr_do"          },
            new SymbolLabel { ID = 6, Name = "dry-clean-kr_do-not"      },
            new SymbolLabel { ID = 7, Name = "dry-clean_do"             },
            new SymbolLabel { ID = 8, Name = "dry-clean_do-gentle"      },
            new SymbolLabel { ID = 9, Name = "dry-clean_do-not"         },
            new SymbolLabel { ID = 10, Name = "dry-clean_do-perm-press" },
            new SymbolLabel { ID = 11, Name = "dry-jp_normal"           },
            new SymbolLabel { ID = 12, Name = "dry-jp_shadow"           },
            new SymbolLabel { ID = 13, Name = "dry-kr_normal"           },
            new SymbolLabel { ID = 14, Name = "dry-kr_shadow"           },
            new SymbolLabel { ID = 15, Name = "dry_normal"              },
            new SymbolLabel { ID = 16, Name = "dry_shadow"              },
            new SymbolLabel { ID = 17, Name = "flame-warn-kr"           },
            new SymbolLabel { ID = 18, Name = "hand-wash"               },
            new SymbolLabel { ID = 19, Name = "hand-wash-jp"            },
            new SymbolLabel { ID = 20, Name = "iron_do"                 },
            new SymbolLabel { ID = 21, Name = "iron_do-not"             },
            new SymbolLabel { ID = 22, Name = "iron_do-not-steam"       },
            new SymbolLabel { ID = 23, Name = "iron_do-steam"           },
            new SymbolLabel { ID = 24, Name = "iron_do-with-cloth"      },
            new SymbolLabel { ID = 25, Name = "tumble-dry_do"           },
            new SymbolLabel { ID = 26, Name = "tumble-dry_do-gentle"    },
            new SymbolLabel { ID = 27, Name = "tumble-dry_do-not"       },
            new SymbolLabel { ID = 28, Name = "tumble-dry_do-perm-press"},
            new SymbolLabel { ID = 29, Name = "wash-jp_do"              },
            new SymbolLabel { ID = 30, Name = "wash-jp_do-not"          },
            new SymbolLabel { ID = 31, Name = "wash_do"                 },
            new SymbolLabel { ID = 32, Name = "wash_do-gentle"          },
            new SymbolLabel { ID = 33, Name = "wash_do-not"             },
            new SymbolLabel { ID = 34, Name = "wash_do-perm-press"      },
            new SymbolLabel { ID = 35, Name = "wet-clean_do"            },
            new SymbolLabel { ID = 36, Name = "wet-clean_do-gentle"     },
            new SymbolLabel { ID = 37, Name = "wet-clean_do-not"        },
            new SymbolLabel { ID = 38, Name = "wet-clean_do-perm-press" },
            new SymbolLabel { ID = 39, Name = "wring-jp_do"             },
            new SymbolLabel { ID = 40, Name = "wring-jp_do-not"         },
        };
        #endregion


        #region 생성자 - YOLOXModel()

        /// <summary>
        /// 생성자
        /// </summary>
        public YOLOXModel()
        {
        }
        #endregion

        #region inference 결과 파싱 - ParseDetect(inferenceResult, image)

        /// <summary>
        /// 탐지 파싱하기
        /// </summary>
        public override List<SymbolPrediction> ParseDetect(IDisposableReadOnlyCollection<DisposableNamedOnnxValue> inferenceResult, Image image)
        {
            DenseTensor<float> boxTensor = inferenceResult.First(x => x.Name == this.OutputArray[0]).Value as DenseTensor<float>;
            DenseTensor<float> clsTensor = inferenceResult.First(x => x.Name == this.OutputArray[1]).Value as DenseTensor<float>;
            DenseTensor<float> outputTensor = boxTensor;
            List<SymbolPrediction> resultList = new List<SymbolPrediction>();

            var (xGain, yGain) = (this.Width / (float)image.Width, this.Height / (float)image.Height);

            float gain = System.Math.Min(xGain, yGain);

            var (xPadding, yPadding) = ((this.Width - image.Width * gain) / 2, (this.Height - image.Height * gain) / 2);

            for (int i = 0; i < boxTensor.Dimensions[1]; i++)
            {
                int maxClsIndex = 0;
                float maxClsScore = .0f;

                for (int j = 0; j < this.LabelCount; j++)
                {
                    float tempScore = clsTensor[0, i, j];
                    if (maxClsScore < tempScore)
                    {
                        maxClsIndex = j;
                        maxClsScore = tempScore;
                    }
                }

                //if(maxClsScore <= this.model.Confidence)
                if (maxClsScore <= this.Confidence)
                {
                    continue;
                }

                float xMinimum = (outputTensor[0, i, 0] - xPadding) / gain;
                float yMinimum = (outputTensor[0, i, 1] - yPadding) / gain;
                float xMaximum = (outputTensor[0, i, 2] - xPadding) / gain;
                float yMaximum = (outputTensor[0, i, 3] - yPadding) / gain;

                xMinimum = Clamp(xMinimum, 0, image.Width);
                yMinimum = Clamp(yMinimum, 0, image.Height);
                xMaximum = Clamp(xMaximum, 0, image.Width);
                yMaximum = Clamp(yMaximum, 0, image.Height);

                SymbolLabel label = this.LabelList[maxClsIndex];

                SymbolPrediction prediction = new SymbolPrediction(label, maxClsScore)
                {
                    Rectangle = new RectangleF(xMinimum, yMinimum, xMaximum - xMinimum, yMaximum - yMinimum)
                };

                resultList.Add(prediction);
            }

            return resultList;
        }
        #endregion
    }
}