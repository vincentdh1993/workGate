﻿using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;

namespace LaundrySolution.ScanToStyleCS
{
    /// <summary>
    /// SymbolDetector
    /// </summary>
    public class SymbolDetector<T> : IDisposable where T : SymbolModel
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////// Field
        ////////////////////////////////////////////////////////////////////////////////////////// Private

        #region Field

        /// <summary>
        /// 모델
        /// </summary>
        private readonly T model;

        /// <summary>
        /// 추론 세션
        /// </summary>
        private readonly InferenceSession inferenceSession;

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Constructor
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 생성자 - SymbolDetector()

        /// <summary>
        /// 생성자
        /// </summary>
        public SymbolDetector()
        {
            this.model = Activator.CreateInstance<T>();
        }

        #endregion
        #region 생성자 - SymbolDetector(filePath, options)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="filePath">파일 경로</param>
        /// <param name="options">옵션</param>
        public SymbolDetector(string filePath, SessionOptions options = null) : this()
        {
            this.inferenceSession = new InferenceSession(File.ReadAllBytes(filePath), options ?? new SessionOptions());
        }

        #endregion
        #region 생성자 - SymbolDetector(stream, options)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="stream">스트림</param>
        /// <param name="options">옵션</param>
        public SymbolDetector(Stream stream, SessionOptions options = null) : this()
        {
            using(BinaryReader reader = new BinaryReader(stream))
            {
                this.inferenceSession = new InferenceSession(reader.ReadBytes((int)stream.Length), options ?? new SessionOptions());
            }
        }

        #endregion
        #region 생성자 - SymbolDetector(weightByteArray, options)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="weightByteArray">가중치 바이트 배열</param>
        /// <param name="options">옵션</param>
        public SymbolDetector(byte[] weightByteArray, SessionOptions options = null) : this()
        {
            this.inferenceSession = new InferenceSession(weightByteArray, options ?? new SessionOptions());
        }

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Method
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 예측하기 - Predict(image)

        /// <summary>
        /// 예측하기
        /// </summary>
        /// <param name="image">이미지</param>
        /// <returns>예측하기</returns>
        public List<SymbolPrediction> Predict(Image image)
        {
            return Supress(this.model.ParseDetect(Inference(image), image));
        }

        #endregion
        #region 리소스 해제하기 - Dispose()

        /// <summary>
        /// 리소스 해제하기
        /// </summary>
        public void Dispose()
        {
            this.inferenceSession.Dispose();
        }

        #endregion

        ////////////////////////////////////////////////////////////////////////////////////////// Private

        #region 크기 변경 비트맵 구하기 - GetResizeBitmap(image)

        /// <summary>
        /// 크기 변경 비트맵 구하기
        /// </summary>
        /// <param name="image">이미지</param>
        /// <returns>크기 변경 비트맵</returns>
        public Bitmap GetResizeBitmap(Image image)
        {
            PixelFormat pixelFormat = image.PixelFormat;

            Bitmap bitmap = new Bitmap(this.model.Width, this.model.Height, pixelFormat);

            using(Graphics graphics = Graphics.FromImage(bitmap))
            {
                graphics.Clear(Color.FromArgb(0, 0, 0, 0));

                var (widthRatio, heightRatio) = (this.model.Width / (float)image.Width, this.model.Height / (float)image.Height);

                float ratio = Math.Min(widthRatio, heightRatio);

                var (width, height) = ((int)(image.Width * ratio), (int)(image.Height * ratio));

                var (x, y) = ((this.model.Width / 2) - (width / 2), (this.model.Height / 2) - (height / 2));

                graphics.DrawImage(image, new Rectangle(x, y, width, height));
            }

            return bitmap;
        }

        #endregion
        #region 픽셀 추출하기 - ExtractPixels(image)

        /// <summary>
        /// 픽셀 추출하기
        /// </summary>
        /// <param name="image">이미지</param>
        /// <returns>텐서</returns>
        private Tensor<float> ExtractPixels(Image image)
        {
            Bitmap bitmap = new Bitmap(image);

            Rectangle rectangle = new Rectangle(0, 0, image.Width, image.Height);

            BitmapData bitmapData = bitmap.LockBits(rectangle, ImageLockMode.ReadOnly, image.PixelFormat);

            DenseTensor<float> tensor = new DenseTensor<float>(new[] { 1, 3, image.Height, image.Width });

            unsafe
            {
                for(int y = 0; y < bitmapData.Height; y++)
                {
                    byte* pointer = (byte*)bitmapData.Scan0 + (y * bitmapData.Stride);
                    int byteOfPixel = bitmapData.Stride / bitmapData.Width;

                    for (int x = 0; x < bitmapData.Width; x++)
                    {
                        switch(this.model.InputColor)
                        {
                            case SymbolModel.ColorField.RgbLong:
                                tensor[0, 0, y, x] = pointer[x * byteOfPixel + 0];
                                tensor[0, 1, y, x] = pointer[x * byteOfPixel + 1];
                                tensor[0, 2, y, x] = pointer[x * byteOfPixel + 2];
                                break;
                            case SymbolModel.ColorField.RgbFloat:
                                tensor[0, 0, y, x] = pointer[x * byteOfPixel + 0] / 255.0f;
                                tensor[0, 1, y, x] = pointer[x * byteOfPixel + 1] / 255.0f;
                                tensor[0, 2, y, x] = pointer[x * byteOfPixel + 2] / 255.0f;
                                break;
                            default:
                                break;
                        }
                    }
                }

                bitmap.UnlockBits(bitmapData);
            }

            return tensor;
        }

        #endregion
        #region 추론하기 - Inference(image)

        /// <summary>
        /// 추론하기
        /// </summary>
        /// <param name="image">이미지</param>
        /// <returns>밀집 텐서 배열</returns>
        private IDisposableReadOnlyCollection<DisposableNamedOnnxValue> Inference(Image image)
        {
            Bitmap resizedBitmap = null;

            if(image.Width != this.model.Width || image.Height != this.model.Height)
            {
                resizedBitmap = GetResizeBitmap(image);
            }

            string inputTensorName = inferenceSession.InputMetadata.Keys.First();
            List<NamedOnnxValue> inputList = new List<NamedOnnxValue>
            {
                NamedOnnxValue.CreateFromTensor(inputTensorName, ExtractPixels(resizedBitmap ?? image))
            };

            IDisposableReadOnlyCollection<DisposableNamedOnnxValue> resultCollection = this.inferenceSession.Run(inputList);


            return resultCollection;
        }

        #endregion



        #region XYXY 배열 구하기 - GetXYXYArray(sourceArray)

        /// <summary>
        /// XYXY 배열 구하기
        /// </summary>
        /// <param name="sourceArray">소스 배열</param>
        /// <returns>XYXY 배열</returns>
        /// <remarks>xywh bbox 형식을 xyxy로 변환한다.</remarks>
        private float[] GetXYXYArray(float[] sourceArray)
        {
            float[] targetArray = new float[4];

            targetArray[0] = sourceArray[0] - sourceArray[2] / 2f;
            targetArray[1] = sourceArray[1] - sourceArray[3] / 2f;
            targetArray[2] = sourceArray[0] + sourceArray[2] / 2f;
            targetArray[3] = sourceArray[1] + sourceArray[3] / 2f;

            return targetArray;
        }

        #endregion


        #region 억제하기 - Supress(sourceList)

        /// <summary>
        /// 억제하기
        /// </summary>
        /// <param name="sourceList">소스 리스트</param>
        /// <returns>억제 리스트</returns>
        private List<SymbolPrediction> Supress(List<SymbolPrediction> sourceList)
        {
            List<SymbolPrediction> targetList = new List<SymbolPrediction>(sourceList);

            foreach(SymbolPrediction source in sourceList)
            {
                foreach(SymbolPrediction target in targetList.ToList())
                {
                    if(target == source)
                    {
                        continue;
                    }

                    var (rectangle1, rectangle2) = (source.Rectangle, target.Rectangle);

                    RectangleF intersectionRectangle = RectangleF.Intersect(rectangle1, rectangle2);

                    float intesectionArea = intersectionRectangle.GetArea();
                    float unionArea       = rectangle1.GetArea() + rectangle2.GetArea() - intesectionArea;
                    float overlap         = intesectionArea / unionArea;

                    if(overlap > this.model.Overlap)
                    {
                        if(source.Score > target.Score)
                        {
                            targetList.Remove(target);
                        }
                    }
                }
            }

            return targetList;
        }

        #endregion
    }
}