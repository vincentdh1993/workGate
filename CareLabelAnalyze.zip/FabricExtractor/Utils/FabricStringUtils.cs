﻿using F23.StringSimilarity;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LaundrySolution.ScanToStyleCS.FabricExtractor.Utils
{
    public static class FabricStringUtils
    {
        public static int MAX_FABRIC_LENGTH = 40;
        public static readonly FabricData fabricData = LoadFabricData();
        private static readonly WeightedLevenshtein weightedLevenshtein = new WeightedLevenshtein(new CharacterSubstitution());
        private static readonly LongestCommonSubsequence longestCommonSubsequence = new LongestCommonSubsequence();

        private static FabricData LoadFabricData(string path = "CareLabelAnalyze/FabricExtractor/Resource/fabric_data.json")
        {
            string fabricDataJson = System.IO.File.ReadAllText(path);
            return JsonConvert.DeserializeObject<FabricData>(fabricDataJson);
        }

        public static string ReplaceNumberAndMark(string text)
        {
            return Regex.Replace(text, "[^\uAC00-\uD7A3a-zA-Z]", "");
        }

        public static List<Tuple<string, string, int, int>> GetFabricWord(string s)
        {
            string reg_str = string.Join("|", fabricData.FabricWordList);
            Regex pattern = new Regex(reg_str, RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture);

            List<Tuple<string, string, int, int>> retList = new List<Tuple<string, string, int, int>>();
            foreach (Match m in pattern.Matches(s))
            {
                string synonymLabel = ReplaceNumberAndMark(
                    fabricData.FabricWordDict[m.Value.ToLower()].ToLower()
                );
                if (fabricData.FabricSynonymData.ContainsKey(synonymLabel))
                {
                    synonymLabel = fabricData.FabricSynonymData[synonymLabel];
                }
                retList.Add(new Tuple<string, string, int, int>(m.Value, synonymLabel, m.Index, m.Index + m.Length));
            }
            return retList;
        }

        public static Tuple<string, double> GetSimilarFabric(string text, double cutoff = 0.7)
        {
            if (text.Length == 0)
            {
                return new Tuple<string, double>(null, 0.0);
            }

            double result_similarity = 0.0;

            string s1 = SplitKoreanPhonetics(text);

            List<string> filtered_kor_list = fabricData.FabricDataList
                .Where(name => text.Length - 1 <= name.Length && name.Length <= text.Length + 2)
                .ToList();

            Tuple<string, double> korResult = GetSimilarFabricName(filtered_kor_list, s1, cutoff, true);
            string kor_result = korResult.Item1;
            result_similarity = korResult.Item2;

            if (kor_result != null && fabricData.FabricSynonymData.ContainsKey(kor_result))
            {
                kor_result = fabricData.FabricSynonymData[kor_result];
            }
            return new Tuple<string, double>(kor_result, result_similarity);
        }

        public static Tuple<string, double> GetSimilarFabricName(List<string> wordList, string s1, double cutoff = 0.7, bool isKorean = false)
        {
            string result = null;
            double resultSimilarity = 0.0;

            int lowerCount = s1.Count(char.IsLower);
            bool isLower = s1.Length / 2 < lowerCount;

            foreach (string word in wordList)
            {
                string s2 = isKorean ? SplitKoreanPhonetics(word) : word;
                if (isLower)
                {
                    s2 = s2.ToLower();
                    s1 = s1.ToLower();
                }
                else
                {
                    s2 = s2.ToUpper();
                    s1 = s1.ToUpper();
                }

                double similarScore1 = GetSimilarScore(s1, s2, true);
                double similarScore2 = GetSimilarScore(s1, s2, false);
                double similarScore = (similarScore1 * 0.5) + (similarScore2 * 0.5);

                if (word.Length < 3)
                {
                    similarScore = Math.Pow(similarScore, 2);
                }

                if (similarScore < cutoff)
                {
                    continue;
                }

                if (resultSimilarity < similarScore)
                {
                    result = word;
                    resultSimilarity = similarScore;
                }
            }
            return new Tuple<string, double>(result, resultSimilarity);
        }

        /// <summary>
        /// 한글 문자열을 초성, 중성, 종성으로 분리합니다.
        /// </summary>
        /// <param name="input">분리할 한글 문자열</param>
        /// <returns>초성, 중성, 종성으로 분리된 문자열</returns>
        public static string SplitKoreanPhonetics(string input)
        {
            StringBuilder result = new StringBuilder();

            foreach (char c in input)
            {
                if (!IsHangulSyllable(c))
                {
                    result.Append(c);
                    continue;
                }

                var (initialSound, medialVowel, finalSound) = GetKoreanPhonetics(c);
                result.Append(initialSound);
                result.Append(medialVowel);

                if (finalSound == '\0')
                {
                    result.Append("   ");
                }
                else
                {
                    result.Append(finalSound);
                }
            }

            return result.ToString();
        }

        private static bool IsHangulSyllable(char c)
        {
            int code = c - 0xAC00;
            return 0 <= code && code <= 0xD7A3 - 0xAC00;
        }

        private static (char initialSound, char medialVowel, char finalSound) GetKoreanPhonetics(char c)
        {
            int code = c - 0xAC00;
            int cho = code / (21 * 28);
            int jung = code % (21 * 28) / 28;
            int jong = code % 28;

            return ((char)(cho + 0x1100), (char)(jung + 0x1161), jong == 0 ? '\0' : (char)(jong + 0x11A7));
        }

        public static double GetSimilarScore(string s1, string s2, bool isSplitKor = true)
        {
            if (isSplitKor)
            {
                s1 = SplitKoreanPhonetics(s1.Replace(" ", ""));
                s2 = SplitKoreanPhonetics(s2.Replace(" ", ""));
            }
            else
            {
                s1 = s1.Replace(" ", "");
                s2 = s2.Replace(" ", "");
            }

            var wlevSim = 1 - (
                weightedLevenshtein.Distance(s1, s2) / (s1.Length + s2.Length)
            );

            var lcsSim = 1 - (
                longestCommonSubsequence.Distance(s1, s2) / (s1.Length + s2.Length)
            );

            var tempSimilarity = (wlevSim * 0.4) + (lcsSim * 0.6);

            return tempSimilarity;
        }
    }

    public class CharacterSubstitution : ICharacterSubstitution
    {
        public double Cost(char c1, char c2)
        {
            if (!FabricStringUtils.fabricData.CharSimScoreList.ContainsKey(c1))
            {
                return 1.0f;
            }
            if (!FabricStringUtils.fabricData.CharSimScoreList[c1].ContainsKey(c2))
            {
                return 1.0f;
            }
            return FabricStringUtils.fabricData.CharSimScoreList[c1][c2];
        }

        public double DeletionCost(char c1)
        {
            return 2.0f;
        }

        public double InsertionCost(char c1)
        {
            return 2.0f;
        }
    }
}