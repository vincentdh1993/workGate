﻿using Newtonsoft.Json;
using LaundrySolution.ScanToStyleCS.FabricExtractor.OcrEngine.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaundrySolution.ScanToStyleCS.FabricExtractor.Models
{
    public class FabricItem
    {
        [JsonProperty("label")]
        public string Label;
        [JsonProperty("origin_label")]
        public string OriginLabel;
        [JsonProperty("percent")]
        public string Percent;
        private Field _poly;
        public Field Poly { get { return _poly; } set { _poly = value; RefreshPoints(); } }
        [JsonProperty("index")]
        public int Index;
        public List<int> IndexList;
        public double Similarity;
        [JsonProperty("outlier_check")]
        public bool Outlier = false;
        [JsonProperty("points")]
        public List<double> points;
        [JsonProperty("category")]
        public string category = "shell";

        private void RefreshPoints()
        {
            points = new List<double>();
            if (_poly == null)
            {
                return;
            }
            foreach(Point point in _poly.BoundingPoly.Vertices)
            {
                points.Add(point.X);
                points.Add(point.Y);
            }
        }

        public FabricItem(string label, string originLabel, string percent, Field poly, int index, double similarity = .0f, List<int> indexList = null)
        {
            Label = label;
            OriginLabel = originLabel;
            Percent = percent;
            Poly = poly;
            Index = index;
            Similarity = similarity;
            if (indexList == null)
            {
                indexList = new List<int>();
                indexList.Add(index);
            } else
            {
                IndexList = indexList;
            }
        }
    }
}
