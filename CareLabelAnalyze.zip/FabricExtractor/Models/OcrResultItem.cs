﻿using Newtonsoft.Json;
using LaundrySolution.ScanToStyleCS.FabricExtractor.OcrEngine.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaundrySolution.ScanToStyleCS.FabricExtractor.OcrEngine
{
    public class OcrResultItem
    {
        [JsonProperty("version")]
        public string Version { get; set; }
        [JsonProperty("requestId")]
        public string RequestId { get; set; }
        [JsonProperty("timestamp")]
        public long Timestamp { get; set; }
        [JsonProperty("images")]
        public ResultImage[] Images { get; set; }

        public class ResultImage
        {
            [JsonProperty("uid")]
            public string Uid { get; set; }
            [JsonProperty("name")]
            public string Name { get; set; }
            [JsonProperty("inferResult")]
            public string InferResult { get; set; }
            [JsonProperty("message")]
            public string Message { get; set; }
            [JsonProperty("fields")]
            public List<Field> Fields { get; set; }
        }
    }
}
