﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaundrySolution.ScanToStyleCS.FabricExtractor.OcrEngine.Models
{
    public class BoundingPoly
    {
        [JsonProperty("vertices")]
        public List<Point> Vertices { get; set; }

        public BoundingPoly()
        {
            Vertices = new List<Point>();
        }

        /// <summary>
        /// 영역의 중심을 계산하는 메소드입니다.
        /// </summary>
        /// <returns>영역의 중심 좌표</returns>
        public Point FindCentroid()
        {
            return new Point(Vertices.Sum(p => p.X) / Vertices.Count, Vertices.Sum(p => p.Y) / Vertices.Count);
        }

        /// <summary>
        /// 다각형의 각 정점을 중심점을 기준으로 정렬합니다.
        /// </summary>
        /// <returns>정렬된 정점 리스트</returns>
        public List<Point> SortVertices()
        {
            Point center = FindCentroid();
            Vertices.Sort((a, b) =>
            {
                double angleA = Math.Atan2(a.X - center.X, a.Y - center.Y);
                double angleB = Math.Atan2(b.X - center.X, b.Y - center.Y);
                return angleA.CompareTo(angleB);
            });

            return Vertices;
        }

        /// <summary>
        /// 다각형의 면적을 계산합니다.
        /// </summary>
        /// <remarks>
        /// 면적이 양수이면 다각형의 꼭짓점이 반시계 방향으로 놓여 있으며, 음수이면 시계 방향으로 놓여 있습니다.
        /// </remarks>
        /// <returns>다각형의 면적</returns>
        public double GetPolygonArea()
        {
            int i, j;
            double ret = 0;

            for (i = Vertices.Count - 1, j = 0; j < Vertices.Count; i = j++)
                ret += Vertices[i].X * Vertices[j].Y - Vertices[j].X * Vertices[i].Y;

            return Math.Abs(ret / 2);
        }


        /// <summary>
        /// p1, p2, p3로 이루어진 삼각형이 반시계 방향인지 시계 방향인지, 또는 일직선인지를 판단합니다.
        /// </summary>
        /// <param name="p1">삼각형의 첫 번째 정점</param>
        /// <param name="p2">삼각형의 두 번째 정점</param>
        /// <param name="p3">삼각형의 세 번째 정점</param>
        /// <returns>
        /// 삼각형이 반시계 방향이면 1을 반환합니다.
        /// 삼각형이 시계 방향이면 -1을 반환합니다.
        /// 삼각형이 일직선상에 있으면 0을 반환합니다.
        /// </returns>
        public int CCW(Point p1, Point p2, Point p3)
        {
            double crossProduct = (p2.X - p1.X) * (p3.Y - p1.Y) - (p3.X - p1.X) * (p2.Y - p1.Y);
            return crossProduct > 0 ? 1 : crossProduct < 0 ? -1 : 0;
        }

        /// <summary>
        /// 두 선분이 교차하는지 여부를 반환합니다.
        /// </summary>
        /// <param name="l1p1">첫 번째 선분의 첫 번째 정점</param>
        /// <param name="l1p2">첫 번째 선분의 두 번째 정점</param>
        /// <param name="l2p1">두 번째 선분의 첫 번째 정점</param>
        /// <param name="l2p2">두 번째 선분의 두 번째 정점</param>
        /// <returns>두 선분이 교차하면 true, 그렇지 않으면 false를 반환합니다.</returns>
        private bool LineIntersection(Point l1p1, Point l1p2, Point l2p1, Point l2p2)
        {
            return CCW(l1p1, l1p2, l2p1) * CCW(l1p1, l1p2, l2p2) < 0 &&
                   CCW(l2p1, l2p2, l1p1) * CCW(l2p1, l2p2, l1p2) < 0;
        }

        /// <summary>
        /// 두 선분이 교차하는 경우 교점을 반환합니다.
        /// </summary>
        /// <param name="p1">첫 번째 선분의 첫 번째 정점</param>
        /// <param name="p2">첫 번째 선분의 두 번째 정점</param>
        /// <param name="p3">두 번째 선분의 첫 번째 정점</param>
        /// <param name="p4">두 번째 선분의 두 번째 정점</param>
        /// <returns>두 선분이 교차하는 경우 교점을 반환합니다.</returns>
        private Point IntersectionPoint(Point p1, Point p2, Point p3, Point p4)
        {
            var denominator = (p1.X - p2.X) * (p3.Y - p4.Y) - (p1.Y - p2.Y) * (p3.X - p4.X);
            var x = ((p1.X * p2.Y - p1.Y * p2.X) * (p3.X - p4.X) - (p1.X - p2.X) * (p3.X * p4.Y - p3.Y * p4.X)) / denominator;
            var y = ((p1.X * p2.Y - p1.Y * p2.X) * (p3.Y - p4.Y) - (p1.Y - p2.Y) * (p3.X * p4.Y - p3.Y * p4.X)) / denominator;

            return new Point(x, y);
        }


        /// <summary>
        /// 다각형의 내부 혹은 외부인지를 판별합니다.
        /// </summary>
        /// <param name="p">검사할 점</param>
        /// <returns>
        /// 0: 외부
        /// 1: 내부
        /// </returns>
        public int PolygonInOut(Point p)
        {
            int intersections = 0;

            Point outsidePoint = new Point(1, 1234567);
            List<Point> line = new List<Point> { outsidePoint, p };

            for (int i = 0; i < Vertices.Count; i++)
            {
                List<Point> segment = new List<Point> { Vertices[i], Vertices[(i + 1) % Vertices.Count] };

                if (CCW(Vertices[i], Vertices[(i + 1) % Vertices.Count], p) == 0)
                {
                    double minX = Math.Min(Vertices[i].X, Vertices[(i + 1) % Vertices.Count].X);
                    double maxX = Math.Max(Vertices[i].X, Vertices[(i + 1) % Vertices.Count].X);
                    double minY = Math.Min(Vertices[i].Y, Vertices[(i + 1) % Vertices.Count].Y);
                    double maxY = Math.Max(Vertices[i].Y, Vertices[(i + 1) % Vertices.Count].Y);

                    if (minX <= p.X && p.X <= maxX && minY <= p.Y && p.Y <= maxY)
                    {
                        return 1;
                    }
                }
                else if (LineIntersection(line[0], line[1], segment[0], segment[1]))
                {
                    intersections++;
                }
            }

            return intersections % 2;
        }

        /// <summary>
        ///  BoundingPoly 타입의 두 다각형(다각형 내부에 점이 위치한 영역)의 교차 영역을 계산합니다.
        /// </summary>
        /// <param name="target">교차 영역을 계산할 BoundingPoly 타입의 대상 다각형입니다.</param>
        /// <returns>double: 교차 영역의 넓이를 나타내는 double 값입니다.</returns>
        public double GetIntersection(BoundingPoly target)
        {
            double ret;
            BoundingPoly intersectionPoly = new BoundingPoly();
            SortVertices();
            target.SortVertices();

            for (int i = 0; i < Vertices.Count; i++)
            {
                Point l1A = Vertices[i];
                Point l1B = Vertices[i + 1 == Vertices.Count ? (0) : (i + 1)];

                for (int j = 0; j < target.Vertices.Count; ++j)
                {
                    Point l2A = target.Vertices[j];
                    Point l2B = target.Vertices[j + 1 == target.Vertices.Count ? (0) : (j + 1)];

                    if (LineIntersection(l1A, l1B, l2A, l2B))
                    {
                        intersectionPoly.Vertices.Add(IntersectionPoint(l1A, l1B, l2A, l2B));
                    }
                }
            }

            foreach (Point vertex in Vertices)
            {
                if (target.PolygonInOut(vertex) != 0)
                {
                    intersectionPoly.Vertices.Add(vertex);
                }
            }
            foreach (Point vertex in target.Vertices)
            {
                if (PolygonInOut(vertex) != 0)
                {
                    intersectionPoly.Vertices.Add(vertex);
                }
            }

            intersectionPoly.SortVertices();

            ret = intersectionPoly.GetPolygonArea();
            return ret;
        }

        /// <summary>
        /// 이 BoundingPoly와 대상 BoundingPoly 사이의 IoU(Intersection over Union)를 반환합니다.
        /// IoU는 교집합 영역과 합집합 영역의 비율입니다.
        /// </summary>
        /// <param name="target">교집합 및 합집합 영역을 계산할 대상 BoundingPoly입니다.</param>
        /// <returns>이 BoundingPoly와 대상 BoundingPoly 사이의 IoU입니다.</returns>
        public double GetIoU(BoundingPoly target)
        {
            double intersection_area = GetIntersection(target);
            double union_area = GetPolygonArea() + target.GetPolygonArea() - intersection_area;

            return intersection_area / union_area;
        }

        private BoundingPoly OrderPoints()
        {
            // initialzie a list of coordinates that will be ordered
            // such that the first entry in the list is the top-left,
            // the second entry is the top-right, the third is the
            // bottom-right, and the fourth is the bottom-left
            BoundingPoly rect = new BoundingPoly();


            // the top-left point will have the smallest sum, whereas
            // the bottom-right point will have the largest sum
            double[] s = Enumerable.Range(0, Vertices.Count)
                .Select(i => Vertices[i].X + Vertices[i].Y)
                .ToArray();

            rect.Vertices[0].X = Vertices[Array.IndexOf(s, s.Min())].X;
            rect.Vertices[0].Y = Vertices[Array.IndexOf(s, s.Min())].Y;
            rect.Vertices[2].X = Vertices[Array.IndexOf(s, s.Max())].X;
            rect.Vertices[2].Y = Vertices[Array.IndexOf(s, s.Max())].Y;

            // now, compute the difference between the points, the
            // top-right point will have the smallest difference,
            // whereas the bottom-left will have the largest difference
            double[] diff = new double[Vertices.Count];
            for (int i = 0; i < Vertices.Count; i++)
            {
                diff[i] = Vertices[i].Y - Vertices[i].X;
            }

            rect.Vertices[1].X = Vertices[Array.IndexOf(diff, diff.Min())].X;
            rect.Vertices[1].Y = Vertices[Array.IndexOf(diff, diff.Min())].Y;
            rect.Vertices[3].X = Vertices[Array.IndexOf(diff, diff.Max())].X;
            rect.Vertices[3].Y = Vertices[Array.IndexOf(diff, diff.Max())].Y;

            return rect;
        }
    }
}
