﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaundrySolution.ScanToStyleCS.FabricExtractor.OcrEngine.Models
{
    public class Field
    {
        [JsonProperty("valueType")]
        public string ValueType { get; set; }
        [JsonProperty("inferText")]
        public string InferText { get; set; }
        [JsonProperty("inferConfidence")]
        public float InferConfidence { get; set; }
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("lineBreak")]
        public bool LineBreak { get; set; }
        [JsonProperty("boundingPoly")]
        public BoundingPoly BoundingPoly { get; set; }
        public Point CenterPoint { get; set; }
        public Point[] Line { get; set; }
        public double Slope { get; set; }
        public int LineNum { get; set; }


        public double CalcSlope()
        {
            double cx = BoundingPoly.Vertices.Sum(vertice => vertice.X) / BoundingPoly.Vertices.Count;
            double cy = BoundingPoly.Vertices.Sum(vertice => vertice.Y) / BoundingPoly.Vertices.Count;
            CenterPoint = new Point(cx, cy);


            Line = new Point[]
            {
                new Point((BoundingPoly.Vertices[0].X + BoundingPoly.Vertices[3].X) / 2, (BoundingPoly.Vertices[0].Y + BoundingPoly.Vertices[3].Y) / 2),
                new Point((BoundingPoly.Vertices[1].X + BoundingPoly.Vertices[2].X) / 2, (BoundingPoly.Vertices[1].Y + BoundingPoly.Vertices[2].Y) / 2)
            };

            double dx = Line[1].X - Line[0].X;
            double dy = (Line[1].Y - Line[0].Y) / dx;

            double[] v1 = new double[] { BoundingPoly.Vertices[1].X - cx, BoundingPoly.Vertices[1].Y - cy };
            double[] v2 = new double[] { BoundingPoly.Vertices[2].X - cx, BoundingPoly.Vertices[2].Y - cy };
            double v1_size = Math.Sqrt(Math.Pow(v1[0], 2) + Math.Pow(v1[1], 2));
            double v2_size = Math.Sqrt(Math.Pow(v2[0], 2) + Math.Pow(v2[1], 2));
            double inner = v1[0] * v2[0] + v1[1] * v2[1];
            double cos_value = inner / (v1_size * v2_size);
            if (InferText.Length >= 2 && cos_value < 0)
            {
                Slope = -20000;  // vertical case
            }
            else if (dy != 0 || cos_value > 0.7)
            {
                Slope = dy;
            }
            else
            {
                Slope = -10000;  // unknown case (etc. right rect )
            }

            return Slope;
        }

        public List<Field> SplitFieldPoly()
        {
            var retField = new List<Field>();

            var tl = BoundingPoly.Vertices[0];
            var tr = BoundingPoly.Vertices[1];
            var br = BoundingPoly.Vertices[2];
            var bl = BoundingPoly.Vertices[3];

            var cntChars = InferText.Length;

            var ldx = (bl.X - tl.X) / cntChars;
            var ldy = (bl.Y - tl.Y) / cntChars;
            var rdx = (br.X - tr.X) / cntChars;
            var rdy = (br.Y - tr.Y) / cntChars;

            foreach (var c in InferText)
            {
                var newField = this.deepClone();
                bl.X = tl.X + ldx;
                bl.Y = tl.Y + ldy;
                br.X = tr.X + rdx;
                br.Y = tr.Y + rdy;

                newField.BoundingPoly.Vertices = new List<Point>{ new Point(tl.X, tl.Y), new Point(tr.X, tr.Y), new Point(br.X, br.Y), new Point(bl.X, bl.Y) };
                newField.InferText = c.ToString();
                newField.Slope = -10000;
                newField.CenterPoint = new Point((tl.X + tr.X + br.X + bl.X) / 4, (tl.Y + tr.Y + br.Y + bl.Y) / 4);
                newField.Line = new Point[] { new Point((tl.X + bl.X) / 2, (tl.Y + bl.Y) / 2), new Point((tr.X + br.X) / 2, (tr.Y + br.Y) / 2) };
                retField.Add(newField);
                tl = bl;
                tr = br;
            }
            return retField;
        }

        public double GetMinY()
        {
            double retVal = BoundingPoly.Vertices[0].Y;
            foreach (Point vertice in BoundingPoly.Vertices)
            {
                if (vertice.Y < retVal)
                {
                    retVal = vertice.Y;
                }
            }

            return retVal;
        }

        public double GetMaxY()
        {
            double retVal = BoundingPoly.Vertices[0].Y;
            foreach (Point vertice in BoundingPoly.Vertices)
            {
                if (vertice.Y > retVal)
                {
                    retVal = vertice.Y;
                }
            }

            return retVal;
        }

        public double GetMinX()
        {
            double retVal = BoundingPoly.Vertices[0].X;
            foreach (Point vertice in BoundingPoly.Vertices)
            {
                if (vertice.X < retVal)
                {
                    retVal = vertice.X;
                }
            }

            return retVal;
        }

        public double GetMaxX()
        {
            double retVal = BoundingPoly.Vertices[0].X;
            foreach (Point vertice in BoundingPoly.Vertices)
            {
                if (vertice.X > retVal)
                {
                    retVal = vertice.X;
                }
            }

            return retVal;
        }

        public void SetLineSlope(double slope)
        {
            this.Slope = slope;
            this.Line = new Point[] {
                new Point(this.Line[0].X, this.CenterPoint.Y - ((this.CenterPoint.X - this.Line[0].X) * slope)),
                new Point(this.Line[1].X, this.CenterPoint.Y - ((this.CenterPoint.X - this.Line[1].X) * slope))
            };
        }

        public double CalcIntersectWidth(Field other)
        {
            double left = Math.Min(BoundingPoly.Vertices[0].X, other.BoundingPoly.Vertices[0].X);
            double right = Math.Max(BoundingPoly.Vertices[1].X, other.BoundingPoly.Vertices[1].X);
            return right - left;
        }

        public double GetHeight()
        {
            return GetMaxY() - GetMinY();
        }

        public Field deepClone()
        {
            var jsonObject = JsonConvert.SerializeObject(this);
            Field cloneObject = JsonConvert.DeserializeObject<Field>(jsonObject);
            return cloneObject;
        }

        public override string ToString()
        {
            return InferText;
        }
    }
}
