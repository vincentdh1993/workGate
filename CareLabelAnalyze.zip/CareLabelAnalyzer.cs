﻿using LaundrySolution.ScanToStyleCS.FabricExtractor.ClovaOcrEngine;
using LaundrySolution.ScanToStyleCS.FabricExtractor.Models;
using LaundrySolution.ScanToStyleCS.FabricExtractor.OcrEngine;
using LaundrySolution.ScanToStyleCS.FabricExtractor.Utils;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace LaundrySolution.ScanToStyleCS
{
    /// <summary>
    /// 세탁기호와 섬유명 추출하는 샘플코드 클래스입니다.
    /// </summary>
    public class CareLabelAnalyzer
    {
        private readonly SymbolDetector<YOLOV8Model> scorer;
        private readonly ClovaOcrEngine clovaOcr;

        public CareLabelAnalyzer(string ocrSecretKey = "", string ocrApiGateway = "", string ocrSavedPath = "")
        {
            // 세탁기호 추론에 사용할 onnx 파일 로드
            scorer = new SymbolDetector<YOLOV8Model>("CareLabelAnalyze/CareSymbolDetector/Weight/yolov8-s.onnx");

            if (string.IsNullOrEmpty(ocrSavedPath) || string.IsNullOrEmpty(ocrApiGateway))
            {
                return;
            }
            // ClovaOcrEngine 초기화. ClovaOCR API의 SecretKey, APIGW URL을 인자로 넘겨준다.
            // ex) secretKey - "ZEtwcXBsbklUbHNZQ▚▚▚▚▚1IaEVxaUVTSlFSVWRqZVY="
            //     APGW URL  - "https://1553d0eb0d▚▚▚▚.apigw.ntruss.com/custom/v1/10137/4e54907646fe2aa03e2▚▚▚▚▚31f33efae134ec52c52b37df831c3ab6c097161b/general"
            clovaOcr = new ClovaOcrEngine(ocrSecretKey, ocrApiGateway, ocrSavedPath);
        }

        /// <summary>
        /// 세탁기호 인식과 섬유명 인식하는 샘플코드
        /// 케어라벨 이미지를 받아, 이미지에 포함된 세탁기호와 섬유명정보를 반환한다.
        /// </summary>
        /// <param name="image">세탁기호 이미지</param>
        /// <param name="tag">세탁기호 택</param>
        /// <returns>회전된 각도, 회전된 영상, 세탁기호 인식결과, 섬유명 인식결과, OCR 결과</returns>
        public ResultCareLabelAnalysis AnalyzeImage(Image image, string tag)
        {
            // 영상이 회전되었을 경우를 고려하여 회전 (-45도 ~ 45도)
            Bitmap bitmap = new Bitmap(image);
            int angle = ImageUtils.GetRotateAngle(bitmap);
            bitmap = ImageUtils.RotateImage(bitmap, angle);

            // 세탁기호가 잘 인식되는 각도가 케어라벨이 잘 회전된 경우라 생각하여 90도씩 회전하면서 올바른 회전각을 찾음
            int bestAngle = 0;
            List<SymbolPrediction> bestPredictions = new List<SymbolPrediction>();
            float bestMean = .0f;
            for (int i = 0; i < 4; i++)
            {
                Bitmap rotatedBitmap = ImageUtils.RotateImage(bitmap, i * 90);
                List<SymbolPrediction> predictions = scorer.Predict(rotatedBitmap);
                if (predictions.Count > 0)
                {
                    float harmonicMean = predictions.Count / predictions.Sum(prediction => 1f / prediction.Score);
                    harmonicMean += predictions.Count / 10f;
                    if (harmonicMean > bestMean)
                    {
                        bestAngle = i * 90;
                        bestPredictions = predictions;
                        bestMean = harmonicMean;
                    }
                }
                rotatedBitmap.Dispose();
            }

            if (bestAngle != 0)
            {
                bitmap = ImageUtils.RotateImage(bitmap, bestAngle);
            }
            bestAngle += angle;
            bestPredictions.Sort((p1, p2) => p1.Rectangle.X.CompareTo(p2.Rectangle.X));


            List<FabricItem> fabricItems = new List<FabricItem>();
            string ocrResultText = "";
            if (clovaOcr != null)
            {
                //// 영상의 OCR을 수행하고 OCR 결과에서 섬유명을 추출하는 파트
                // FabricSynonymData를 Clear하지 않으면 대표 섬유명으로 표현됨 (ex. 울 -> 모)
                FabricStringUtils.fabricData.FabricSynonymData.Clear();
                // Image 객체를 사용하여 CLOVA OCR API 호출
                OcrResultItem ocrResult = clovaOcr.RecognizeText(bitmap, tag);
                // OCR결과의 Fields 필드를 사용하여 섬유명 추출
                FabricFinder fabricFinder = new FabricFinder(ocrResult.Images[0].Fields);
                fabricItems = fabricFinder.MakeFabricInfo();
                ocrResultText = fabricFinder.ToString();
            }


            return new ResultCareLabelAnalysis(bestAngle, bitmap, bestPredictions, fabricItems, ocrResultText);
        }


        /// <summary>
        /// AnalyzeImage 의 값 반환에 사용할 클래스
        /// </summary>
        public class ResultCareLabelAnalysis
        {
            public int RotateDegrees { get; set; }
            public System.Drawing.Image RotatedImage { get; set; }
            public List<SymbolPrediction> SymbolList { get; set; }
            public List<FabricItem> FabricItemList { get; set; }
            public string LabelText { get; set; }

            /// <summary>
            /// ResultCareLabelAnalysis 생성자
            /// </summary>
            /// <param name="rotateDegrees">영상을 회전한 각도</param>
            /// <param name="rotatedImage">회전된 영상</param>
            /// <param name="symbolList">세탁기호 리스트</param>
            /// <param name="fabricItems">인식된 섬유명 리스트</param>
            /// <param name="text">OCR결과 Text</param>
            public ResultCareLabelAnalysis(int rotateDegrees, Image rotatedImage, List<SymbolPrediction> symbolList, List<FabricItem> fabricItems, string text)
            {
                RotateDegrees = rotateDegrees;
                RotatedImage = rotatedImage;
                SymbolList = symbolList;
                FabricItemList = fabricItems;
                LabelText = text;
            }
        }
    }
}
